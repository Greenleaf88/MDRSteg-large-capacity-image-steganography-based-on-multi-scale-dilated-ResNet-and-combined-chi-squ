

def test():

    for i in range(10):
        if i == 5:
            break
    print(i)


if __name__ == '__main__':
    test()
    # 输出：5 说明break之后跳出了for循环
