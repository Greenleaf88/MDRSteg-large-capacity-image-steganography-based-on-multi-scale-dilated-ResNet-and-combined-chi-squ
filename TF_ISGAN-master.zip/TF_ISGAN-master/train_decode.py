import os
import time
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
# os.environ["CUDA_VISIBLE_DEVICES"] = "2"
import numpy as np
import cv2
import math

import matplotlib.pyplot as plt
import tensorflow as tf
from tensorflow.data import Iterator

from Dataset import WatermarkDataLoader, WatermarkFinetuneDataLoader
from visulize import save_test_images_without_stego
from utils import rgb2yuv_tf, yuv2rgb_tf, psnr, luv_loss, Chi_Square_Loss_V2, Mean_Chi_Square_Loss_V2, random_transform
from model import Discriminator, encode_net, decode_net
from ResNet import resnet_nopooling, network


class Model():

    def __init__(self):
        self.run_time = time.strftime("%m%d-%H%M")
        # self.learning_rate = 0.0001
        self.starter_learning_rate = 0.003

        self.epoches = 70
        self.log_path = 'logs/'+self.run_time + '/'
        self.alpha = 0.02
        self.batch_size = 8

        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True

        self.sess = tf.InteractiveSession(config=config)
        self.secret_tensor = tf.placeholder(shape=[None, None, None, 1], dtype=tf.float32, name="secret_tensor")
        self.cover_tensor = tf.placeholder(shape=[None, None, None, 3], dtype=tf.float32, name="cover_tensor")
        self.stego_tensor = tf.placeholder(shape=[None, 512, 512, 1], dtype=tf.float32, name="stego_tensor")
        self.global_step_tensor = tf.Variable(0, trainable=False, name='global_step')


    def get_hiding_network_op(self, cover_tensor, secret_tensor, is_training):

        Y = 0 + 0.299 * cover_tensor[:, :, :, 0] + 0.587 * cover_tensor[:, :, :, 1] + 0.114 * cover_tensor[:, :, :, 2]
        CB = 128.0 / 255 - 0.168736 * cover_tensor[:, :, :, 0] - 0.331264 * cover_tensor[:, :, :,1] + 0.5 * cover_tensor[:, :, :, 2]
        CR = 128.0 / 255 + 0.5 * cover_tensor[:, :, :, 0] - 0.418688 * cover_tensor[:, :, :,1] - 0.081312 * cover_tensor[:, :, :, 2]

        Y = tf.expand_dims(Y, -1)
        CB = tf.expand_dims(CB, -1)
        CR = tf.expand_dims(CR, -1)


        concat_input = tf.concat([Y, secret_tensor], axis=-1, name='images_features_concat')
        y_output = network(concat_input, n_class=1, is_training=is_training, name='encode')

        output_r = y_output + 1.402 * CR - 1.402 * 128.0 / 255
        output_g = y_output - 0.344136 * CB + 0.344136 * 128.0 / 255 - 0.714136 * CR + 0.714136 * 128.0 / 255
        output_b = y_output + 1.772 * CB - 1.772 * 128.0 / 255
        output = tf.concat([output_r, output_g, output_b], axis=-1, name='rgb_concat')

        return y_output, output


    def get_reveal_network_op(self, container_tensor, is_training, transform=False):
        if transform:
            container_tensor = 0 + 0.299 * container_tensor[:, :, :, 0] + 0.587 * container_tensor[:, :, :, 1] + 0.114 * container_tensor[:, :, :,2]
            container_tensor = tf.expand_dims(container_tensor, -1)
        output = network(container_tensor, n_class=1, is_training=is_training, name='decode')
        return output

    def get_noise_layer_op(self, tensor, secret_tensor, std=0.01, mode='train'):

        print 'add noise using mode ', mode
        def scale_up(tensor, secret_tensor):
            up_size = tf.random_uniform([1], 513, 520, dtype=tf.int32)[0]
            tensor = tf.image.resize_images(tensor, [up_size, up_size])
            tensor = tf.random_crop(tensor, [self.batch_size, 512, 512, 1], seed =1)

            secret_tensor = tf.image.resize_images(secret_tensor, [up_size, up_size])
            secret_tensor = tf.random_crop(secret_tensor, [self.batch_size, 512, 512, 1], seed=1)

            return tensor, secret_tensor

        def scale_down(tensor, secret_tensor):
            down_size = tf.random_uniform([1], 503, 512, dtype=tf.int32)[0]
            tensor = tf.random_crop(tensor, [self.batch_size, down_size, down_size, 1], seed=2)
            tensor = tf.image.resize_images(tensor, [512, 512])

            secret_tensor = tf.random_crop(secret_tensor, [self.batch_size, down_size, down_size, 1], seed=2)
            secret_tensor = tf.image.resize_images(secret_tensor, [512, 512])

            return tensor, secret_tensor

        def rotate(tensor, secret_tensor, angle=0.):
            if angle == 0.:
                angle = tf.random_uniform([1], math.radians(1), math.radians(3), dtype=tf.float32)
            tensor = tf.contrib.image.rotate(tensor, angle)
            secret_tensor = tf.contrib.image.rotate(secret_tensor, angle)
            return tensor, secret_tensor

        def add_noise(tensor, secret_tensor):
            random =tf.random_normal(shape=tf.shape(tensor), mean=0.0, stddev=std, dtype=tf.float32)
            tensor = tensor + random
            secret_tensor = secret_tensor + random
            return tensor, secret_tensor

        def translate(tensor, secret_tensor):
            size = tf.random_uniform([1], 0, 3, dtype=tf.float32)[0]
            tensor = tf.contrib.image.translate(tensor, [size, size])
            secret_tensor = tf.contrib.image.translate(secret_tensor, [size, size])
            return tensor, secret_tensor

        if mode == 'test':
            # stego_noise, secret_noise = rotate(tensor, secret_tensor, angle=math.radians(3))
            stego_noise, secret_noise = rotate(tensor, secret_tensor, angle=math.radians(1))
            # stego_noise, secret_noise = translate(tensor, secret_tensor)
            # stego_noise, secret_noise = scale_down(tensor, secret_tensor)
            return stego_noise, secret_noise

        if mode == 'train':
            with tf.variable_scope("transform_layer"):
                stego_noise = tensor
                secret_noise = secret_tensor
                # stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.7, lambda : add_noise(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : rotate(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : translate(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : scale_up(stego_noise, secret_noise), lambda :scale_down(stego_noise, secret_noise))
                return stego_noise, secret_noise

        if mode == 'None':
            return tensor, secret_tensor


    def get_loss_op(self,secret_true,secret_pred, test=False):

        with tf.variable_scope("huber_losses"):
            if test:
                secret_pred = tf.clip_by_value(secret_pred,0,1)
            secret_mse = tf.losses.mean_squared_error(secret_true,secret_pred)

        # with tf.variable_scope("ssim_losses"):
        #     # secret_ssim = tf.reduce_mean(tf.image.ssim(secret_true, secret_pred, max_val=1.0))
        #     # cover_ssim = tf.reduce_mean(tf.image.ssim(cover_true, cover_pred, max_val=1.0))
        #
        #     # if not test:
        #     #     secret_ssim = 1.0 - secret_ssim
        #     #     cover_ssim = 1.0 - cover_ssim
        #     # secret_ssim = Mean_Chi_Square_Loss_V2(secret_pred, secret_true)*self.alpha
        #     # cover_ssim = Mean_Chi_Square_Loss_V2(cover_true, cover_pred)*self.alpha
        #
        #     secret_ssim = tf.zeros(shape=[1])[0]
        #     cover_ssim = tf.zeros(shape=[1])[0]


        G_final_loss = secret_mse
        # return D_final_loss, G_final_loss, D_loss, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim
        # if test:
        #     mse1 = tf.losses.mean_squared_error(secret_true, secret_pred)
        #     mse2 = tf.losses.mean_squared_error(cover_true,cover_pred)
        #     cover_psnr = 10 * tf.log(1 / mse2)
        #     secret_psnr = 10 * tf.log(1 / mse1)

        return G_final_loss, secret_mse

    def get_tensor_to_img_op(self,tensor):
        with tf.variable_scope("",reuse=True):
            # t = tensor*tf.convert_to_tensor([0.229, 0.224, 0.225]) + tf.convert_to_tensor([0.485, 0.456, 0.406])
            # tensor = yuv2rgb_tf(tensor)
            return tf.clip_by_value(tensor,0,1)
            # return tf.clip_by_value(tensor,0,255)

    def prepare_training_graph(self,global_step_tensor):

        reveal_output_op = self.get_reveal_network_op(self.stego_tensor, is_training=True)

        G_final_loss, secret_mse = self.get_loss_op(self.secret_tensor, reveal_output_op)

        global_variables = tf.global_variables()
        gan_varlist = [i for i in global_variables if i.name.startswith('Discriminator')]
        decode_varlist = [i for i in global_variables if i.name.startswith('decode')]
        en_de_code_varlist = [i for i in global_variables if i not in gan_varlist]

        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            G_minimize_op = tf.train.AdamOptimizer(self.learning_rate).minimize(G_final_loss, var_list=decode_varlist, global_step=global_step_tensor)

        # tf.summary.scalar('D_loss', D_final_loss,family='train')
        tf.summary.scalar('G_loss', G_final_loss,family='train')
        tf.summary.scalar('secret_mse', secret_mse,family='train')
        tf.summary.scalar('learning_rate', self.learning_rate,family='train')

        tf.summary.image('secret',self.get_tensor_to_img_op(self.secret_tensor),max_outputs=1,family='train')
        tf.summary.image('stego',self.get_tensor_to_img_op(self.stego_tensor),max_outputs=1,family='train')
        # tf.summary.image('hidden',self.get_tensor_to_img_op(hidden),max_outputs=1,family='train')
        # tf.summary.image('hidden_noisy',self.get_tensor_to_img_op(y_output_transformed),max_outputs=1,family='train')
        tf.summary.image('revealed',self.get_tensor_to_img_op(reveal_output_op),max_outputs=1,family='train')

        merged_summary_op = tf.summary.merge_all()

        return G_minimize_op, G_final_loss, merged_summary_op, secret_mse

    def prepare_test_graph(self):
        reveal_output_op = self.get_reveal_network_op(self.stego_tensor, is_training=False)

        G_final_loss, secret_mse = self.get_loss_op(self.secret_tensor, reveal_output_op,test=True)

        return reveal_output_op, G_final_loss, secret_mse

    def save_chkp(self,path):
        global_step = self.sess.run(self.global_step_tensor)
        self.saver.save(self.sess,path,global_step)

    def load_chkp(self,path):
        self.saver.restore(self.sess,path)
        print("LOADED")

    def train(self):

        with tf.device('/cpu:0'):

            segdl = WatermarkFinetuneDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/stego',
                                                '/mnt/4T/moliq/moliq_imagenet/imagenet/secret', batch_size=4,
                                                split='train')

            segdl_val = WatermarkFinetuneDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/stego',
                                                '/mnt/4T/moliq/moliq_imagenet/imagenet/secret', batch_size=4,
                                                split='val')


        steps_per_epoch = segdl.data_len / segdl.batch_size
        steps_per_epoch_val = segdl_val.data_len / segdl_val.batch_size

        self.learning_rate = tf.train.exponential_decay(self.starter_learning_rate, self.global_step_tensor,steps_per_epoch*8, 0.1, staircase=True)

        self.train_op_G, G_final_loss, self.summary_op, self.secret_mse = self.prepare_training_graph(self.global_step_tensor)

        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)

        self.writer = tf.summary.FileWriter(self.log_path, self.sess.graph)
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(max_to_keep=50)

        loader = tf.train.latest_checkpoint('logs/1214-1959')
        global_variables = tf.global_variables()
        encode_decode_varlist = [i for i in global_variables if not i.name.startswith('Discriminator')]
        exclude_vars = ['beta1_power:0', 'beta2_power:0', 'global_step:0', 'beta1_power_1:0', 'beta2_power_1:0']
        # exclude_vars2 = [i.name for i in encode_decode_varlist if i.name.startswith('encode')]
        # exclude_vars = exclude_vars1+exclude_vars2
        restore_variables = [i for i in encode_decode_varlist if not i.name in exclude_vars]
        custom_saver = tf.train.Saver(var_list=restore_variables)
        custom_saver.restore(self.sess, loader)
        print('load model %s' % loader)
        #

        for epoch in range(1, 1+self.epoches):
            with tf.device('/cpu:0'):

                segdl = WatermarkFinetuneDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/stego',
                                                    '/mnt/4T/moliq/moliq_imagenet/imagenet/secret', batch_size=4,
                                                    split='train')

                segdl_val = WatermarkFinetuneDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/stego',
                                                        '/mnt/4T/moliq/moliq_imagenet/imagenet/secret', batch_size=4,
                                                        split='val')

                iterator = Iterator.from_structure(segdl.data_tr.output_types, segdl.data_tr.output_shapes)
                iterator_val = Iterator.from_structure(segdl_val.data_tr.output_types, segdl_val.data_tr.output_shapes)
                next_batch = iterator.get_next()
                next_batch_val = iterator_val.get_next()
                training_init_op = iterator.make_initializer(segdl.data_tr)
                training_init_op_val = iterator_val.make_initializer(segdl_val.data_tr)

            print('epoch %d'%epoch)
            self.sess.run(training_init_op)
            for i in range(steps_per_epoch):
                try:
                    stego_tensor, secret_tensor = self.sess.run(next_batch)
                except:
                    continue
                _, G_loss, secret_mse, summary, global_step = \
                    self.sess.run([self.train_op_G, G_final_loss, self.secret_mse, self.summary_op, self.global_step_tensor],
                    feed_dict={self.secret_tensor: secret_tensor, self.stego_tensor: stego_tensor})

                if i%10 == 0:
                    self.writer.add_summary(summary, global_step)

                if i % 100 == 0:
                    print('Epoch [{}/{}]  Step [{}/{}] G_final_Loss {:.4f}   decoder_mse {:.4f} '.format(
                        epoch, self.epoches, i, steps_per_epoch, G_loss, secret_mse ))

            # run validation
            self.sess.run(training_init_op_val)
            secret_mse_this_epoch = []
            for i in range(steps_per_epoch_val/10):
                stego_tensor_val, secret_tensor_val = self.sess.run(next_batch_val)
                secret_mse = \
                    self.sess.run(self.secret_mse,feed_dict={self.secret_tensor: secret_tensor_val,
                                                                self.stego_tensor: stego_tensor_val})

                secret_mse_this_epoch.append(secret_mse)

            mean_secret_mse_this_epoch = sum(secret_mse_this_epoch) / len(secret_mse_this_epoch)
            print('VALIDATION Epoch {} global step {}  valid_decoder_mse {:.4f}'.format(epoch, global_step,  mean_secret_mse_this_epoch))

            self.save_chkp(self.log_path)

    def test_performance(self, log_path):

        # hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
        #                         self.prepare_test_graph(self.secret_yuv, self.cover_yuv)
        reveal_output_op, G_final_loss, secret_mse = self.prepare_test_graph()

        loader = tf.train.latest_checkpoint(log_path)

        self.saver = tf.train.Saver()
        self.saver.restore(self.sess, loader)
        print('load model %s'%loader)

        with tf.device('/cpu:0'):

            segdl_val = WatermarkFinetuneDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/stego',
                                                    '/mnt/4T/moliq/moliq_imagenet/imagenet/secret', batch_size=4,
                                                    split='val')

            iterator_val = Iterator.from_structure(segdl_val.data_tr.output_types, segdl_val.data_tr.output_shapes)
            next_batch_val = iterator_val.get_next()
            training_init_op_val = iterator_val.make_initializer(segdl_val.data_tr)

        steps_per_epoch_val = segdl_val.data_len / segdl_val.batch_size

        loss_val_this_epoch = []
        secret_mse_val_this_epoch = []


        self.sess.run(training_init_op_val)

        # self.saver.restore(self.sess, loader)
        # print('load model %s'%loader)


        for i in range(steps_per_epoch_val):
        # for i in range(5):
            cover_tensor_val, secret_tensor_val = self.sess.run(next_batch_val)
            secret_reveal, loss_value, secret_mse_value = self.sess.run([reveal_output_op, G_final_loss, secret_mse],
                              feed_dict={self.secret_tensor: secret_tensor_val,
                                         self.stego_tensor: cover_tensor_val})

            cover_names = segdl_val.imgs_files[i*segdl_val.batch_size:(i+1)*segdl_val.batch_size]
            secret_names = segdl_val.labels_files[i*segdl_val.batch_size:(i+1)*segdl_val.batch_size]

            loss_val_this_epoch.append(loss_value)
            secret_mse_val_this_epoch.append(secret_mse_value)
            if i < 20:
                save_test_images_without_stego(cover_names, secret_names, cover_tensor_val, secret_tensor_val, secret_reveal,log_path)
            if i%50 == 0:
                print('%d loss %.3f secret_mse %.3f'%(i, loss_value, secret_mse_value))

        mean_loss_val_this_epoch = np.mean(loss_val_this_epoch)
        mean_secret_mse_val_this_epoch = np.mean(secret_mse_val_this_epoch)
        psnr_secret = psnr(mean_secret_mse_val_this_epoch)

        print('validation loss: %.4f' % mean_loss_val_this_epoch)
        print('secret mse: %.4f' % mean_secret_mse_val_this_epoch)
        print('secret psnr: %.4f' % psnr_secret)

    def test_one_image(self, log_path, cover_image, secret_image):

        hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
            self.prepare_test_graph(self.secret_tensor, self.cover_tensor)

        loader = tf.train.latest_checkpoint(log_path)

        global_variables = tf.global_variables()
        gan_varlist = [i for i in global_variables if not i.name.startswith('Discriminator')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=gan_varlist)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        stego, secret_reveal, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value = \
            self.sess.run(
                [hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim,
                ],
                feed_dict={self.secret_tensor: secret_image,
                           self.cover_tensor: cover_image})

        stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
        secret_reveal = (np.clip(secret_reveal, 0, 1) * 255).astype(np.uint8)
        return stego, secret_reveal

    def get_stego(self, log_path, cover_image, secret_image):
        y_output, hidden = self.get_hiding_network_op(cover_tensor=self.cover_tensor,secret_tensor=self.secret_tensor, is_training=False)

        loader = tf.train.latest_checkpoint(log_path)
        global_variables = tf.global_variables()
        encode_vars = [i for i in global_variables if i.name.startswith('encode')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=encode_vars)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        stego = self.sess.run(
                hidden,
                feed_dict={self.secret_tensor: secret_image,
                           self.cover_tensor: cover_image})

        stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
        return stego

    def get_noise_images(self, log_path):

        segdl = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_val/',
                                    '/mnt/2T/moliq/Documents/binaryimages/',1 ,
                                    (512, 512), (512, 512),
                                    'dataset/imagenet_train.txt', split='train')
        steps_per_epoch = segdl.data_len / segdl.batch_size

        iterator = Iterator.from_structure(segdl.data_tr.output_types, segdl.data_tr.output_shapes)
        next_batch = iterator.get_next()
        training_init_op = iterator.make_initializer(segdl.data_tr)

        y_output, hidden = self.get_hiding_network_op(cover_tensor=self.cover_tensor,secret_tensor=self.secret_tensor, is_training=False)
        y_output_transformed, secret_tensor_transformed = self.get_noise_layer_op(y_output, self.secret_tensor, mode='None')


        loader = tf.train.latest_checkpoint(log_path)
        global_variables = tf.global_variables()
        encode_vars = [i for i in global_variables if i.name.startswith('encode')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=encode_vars)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        self.sess.run(training_init_op)
        for i in range(steps_per_epoch):
            try:
                cover_tensor, secret_tensor = self.sess.run(next_batch)
            except:
                print 'skipped'
                continue

            out_name = os.path.basename(segdl.imgs_files[i])[:-5] + '_' +os.path.basename(segdl.labels_files[i])[:-5] + '.png'
            y_output_transformed_image, secret_tensor_transformed_image = self.sess.run( [y_output_transformed, secret_tensor_transformed],
                feed_dict={self.secret_tensor: secret_tensor,
                           self.cover_tensor: cover_tensor})

            y_output_transformed_image = (np.clip(y_output_transformed_image, 0, 1) * 255).astype(np.uint8)
            # secret_tensor_transformed_image = (np.clip(secret_tensor_transformed_image, 0, 1) * 255).astype(np.uint8)
            secret_tensor_transformed_image = (secret_tensor_transformed_image > 0.5).astype(np.uint8)*255

            y_output_transformed_image, secret_tensor_transformed_image = random_transform(np.squeeze(y_output_transformed_image), np.squeeze(secret_tensor_transformed_image))
            # cv2.imwrite('/mnt/4T/moliq/moliq_imagenet/imagenet/stego/%s'%(out_name), np.squeeze(y_output_transformed_image))
            cv2.imwrite('/mnt/4T/moliq/moliq_imagenet/imagenet/stego/%s'%(out_name), np.squeeze(y_output_transformed_image))
            cv2.imwrite('/mnt/4T/moliq/moliq_imagenet/imagenet/secret/%s'%(out_name), np.squeeze(secret_tensor_transformed_image))

    def get_secret(self, log_path, stego_image):

        input_placeholder = tf.placeholder(shape=[None, 512, 512, 3], dtype=tf.float32)
        reveal_output_op = self.get_reveal_network_op(input_placeholder, is_training=False, transform=True)
        # reveal_output_op = self.get_reveal_network_op(self.stego_tensor, is_training=False)

        if os.path.exists(log_path+'.meta'):
            loader = log_path
        else:
            loader = tf.train.latest_checkpoint(log_path)
        global_variables = tf.global_variables()
        decode_vars = [i for i in global_variables if i.name.startswith('decode')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=decode_vars)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        secret_reveal = self.sess.run(reveal_output_op, feed_dict={input_placeholder: stego_image})
        secret_reveal = (np.clip(secret_reveal, 0, 1) * 255).astype(np.uint8)
        return secret_reveal

    def test_paper(self, log_path, directory):
        hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = self.prepare_test_graph(self.secret_tensor, self.cover_tensor)
        loader = tf.train.latest_checkpoint(log_path)
        self.saver = tf.train.Saver()
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)
        image_names = os.listdir(directory)
        cover_images_names = [i for i in image_names if i.endswith('0.png')]
        for i, cover_name in enumerate(cover_images_names):
            cover = plt.imread(os.path.join(directory, cover_name))
            secret = plt.imread(os.path.join(directory, cover_name.replace('_0', '_2')))
            # cover = (cover/255.).astype(np.float32)
            # secret = (secret/255.).astype(np.float32)
            cover = np.expand_dims(cover, 0)
            secret = np.expand_dims(secret, 0)

            stego, secret_reveal, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value = \
                self.sess.run(
                    [hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim],
                    feed_dict={self.secret_tensor: secret,
                               self.cover_tensor: cover})

            print('%d loss %.3f secret_mse %.3f cover_mse %.3f secret_ssim %.3f cover_ssim %.3f' % (
            i, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value))

            stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
            # stego = (((stego - stego.min()) * 255) / (stego.max() - stego.min())).astype(np.uint8)
            secret_reveal = (((secret_reveal - secret_reveal.min()) * 255) / (
                    secret_reveal.max() - secret_reveal.min())).astype(np.uint8)
            plt.imsave(os.path.join(directory, cover_name[:-4]+'_us_voc.png'), stego.squeeze())
            plt.imsave(os.path.join(directory, cover_name[:-5]+'2_us_voc.png'), secret_reveal.squeeze())

if __name__ == '__main__':
    train_model = Model()
    # train_model.train()
    train_model.test_performance('logs/1218-1645')




