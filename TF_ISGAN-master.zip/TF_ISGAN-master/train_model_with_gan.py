import os
import time
# os.environ["CUDA_VISIBLE_DEVICES"] = "2"
# os.environ["CUDA_VISIBLE_DEVICES"] = "1"
os.environ["CUDA_VISIBLE_DEVICES"] = "0"
import numpy as np
import math
import matplotlib.pyplot as plt
# import cv2

import tensorflow as tf
from tensorflow.data import Iterator

from Dataset import SegDataLoader, VocRgbDataLoader, VocDataLoader, LfwRgbDataLoader, ImageNetRgbDataLoader, BossDataLoader, WatermarkDataLoader
from visulize import save_test_images, save_stegnalysis_images
from utils import rgb2yuv_tf, yuv2rgb_tf, psnr, luv_loss, Chi_Square_Loss_V2, Mean_Chi_Square_Loss_V2
from model import Discriminator, encode_net, decode_net
from ResNet import resnet_nopooling, network, xunet


class Model():

    def __init__(self):
        self.run_time = time.strftime("%m%d-%H%M")
        # self.learning_rate = 0.0001
        self.starter_learning_rate = 0.003

        self.epoches = 70
        self.log_path = 'logs/'+self.run_time + '/'
        self.alpha = 0.02
        self.batch_size = 4
        # self.alpha = 0.01

        config = tf.ConfigProto()
        config.gpu_options.allow_growth = True

        self.sess = tf.InteractiveSession(config=config)
        self.secret_tensor = tf.placeholder(shape=[None, None, None, 1], dtype=tf.float32, name="secret_tensor")
        self.cover_tensor = tf.placeholder(shape=[None, None, None, 3], dtype=tf.float32, name="cover_tensor")
        self.stego_tensor = tf.placeholder(shape=[None, 512, 512, 1], dtype=tf.float32, name="stego_tensor")
        self.global_step_tensor = tf.Variable(0, trainable=False, name='global_step')


    def get_hiding_network_op(self, cover_tensor, secret_tensor, is_training):

        Y = 0 + 0.299 * cover_tensor[:, :, :, 0] + 0.587 * cover_tensor[:, :, :, 1] + 0.114 * cover_tensor[:, :, :, 2]
        CB = 128.0 / 255 - 0.168736 * cover_tensor[:, :, :, 0] - 0.331264 * cover_tensor[:, :, :,1] + 0.5 * cover_tensor[:, :, :, 2]
        CR = 128.0 / 255 + 0.5 * cover_tensor[:, :, :, 0] - 0.418688 * cover_tensor[:, :, :,1] - 0.081312 * cover_tensor[:, :, :, 2]

        Y = tf.expand_dims(Y, -1)
        CB = tf.expand_dims(CB, -1)
        CR = tf.expand_dims(CR, -1)


        concat_input = tf.concat([Y, secret_tensor], axis=-1, name='images_features_concat')
        y_output = network(concat_input, n_class=1, is_training=is_training, name='encode')

        output_r = y_output + 1.402 * CR - 1.402 * 128.0 / 255
        output_g = y_output - 0.344136 * CB + 0.344136 * 128.0 / 255 - 0.714136 * CR + 0.714136 * 128.0 / 255
        output_b = y_output + 1.772 * CB - 1.772 * 128.0 / 255
        output = tf.concat([output_r, output_g, output_b], axis=-1, name='rgb_concat')

        return y_output, output


    def get_reveal_network_op(self, container_tensor, is_training, transform=False):
        if transform:
            container_tensor = 0 + 0.299 * container_tensor[:, :, :, 0] + 0.587 * container_tensor[:, :, :, 1] + 0.114 * container_tensor[:, :, :,2]
            container_tensor = tf.expand_dims(container_tensor, -1)
        output = network(container_tensor, n_class=1, is_training=is_training, name='decode')
        return output

    def get_discriminator_pred_op(self, input, is_training, reuse):
        pred = xunet(input, n_class=3, name='Discriminator', is_training=is_training, reuse=reuse)
        return pred

    def get_loss_op(self,secret_true,secret_pred,cover_true,cover_pred, fake_logits, real_logits, test=False):

        D_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=real_logits, labels=tf.ones_like(real_logits)) + tf.nn.sigmoid_cross_entropy_with_logits(logits=fake_logits, labels=tf.zeros_like(fake_logits)))
        G_loss = tf.reduce_mean(tf.nn.sigmoid_cross_entropy_with_logits(logits=fake_logits, labels=tf.ones_like(fake_logits)))

        with tf.variable_scope("huber_losses"):
            # if test:
            #     secret_pred = tf.clip_by_value(secret_pred,0,1)
            #     cover_pred = tf.clip_by_value(cover_pred,0,1)
            secret_mse = tf.losses.mean_squared_error(secret_true,secret_pred)
            cover_mse = tf.losses.mean_squared_error(cover_true,cover_pred)
            # secret_mse = 5*tf.losses.mean_squared_error(secret_true,secret_pred)
            # cover_mse = 5*tf.losses.mean_squared_error(cover_true,cover_pred)

        with tf.variable_scope("ssim_losses"):
            if test:
                secret_ssim = tf.reduce_mean(tf.image.ssim(secret_true, secret_pred, max_val=1.0))
                cover_ssim = tf.reduce_mean(tf.image.ssim(cover_true, cover_pred, max_val=1.0))
                secret_ssim = 1.0 - secret_ssim
                cover_ssim = 1.0 - cover_ssim
            else:
                # secret_ssim = Mean_Chi_Square_Loss_V2(secret_pred, secret_true)*self.alpha
                # cover_ssim = Mean_Chi_Square_Loss_V2(cover_true, cover_pred)*self.alpha
                secret_ssim = tf.zeros(shape=[1])[0]
                cover_ssim = tf.zeros(shape=[1])[0]

        D_final_loss = 0.1*D_loss
        G_final_loss = cover_mse + secret_mse + secret_ssim + cover_ssim + 0.1*G_loss

        # alpha = tf.get_variable(name='Alpha', initializer=self.alpha, trainable=False)
        # G_final_loss = 10*cover_mse + 10*secret_mse + secret_ssim + cover_ssim

        # return D_final_loss, G_final_loss, D_loss, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim
        return D_final_loss, G_final_loss, D_loss, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim

    def get_noise_layer_op(self, tensor, secret_tensor, std=0.01, mode='train'):

        print 'add noise using mode ', mode
        def scale_up(tensor, secret_tensor):
            up_size = tf.random_uniform([1], 513, 520, dtype=tf.int32)[0]
            tensor = tf.image.resize_images(tensor, [up_size, up_size])
            tensor = tf.random_crop(tensor, [self.batch_size, 512, 512, 1], seed =1)

            secret_tensor = tf.image.resize_images(secret_tensor, [up_size, up_size])
            secret_tensor = tf.random_crop(secret_tensor, [self.batch_size, 512, 512, 1], seed=1)

            return tensor, secret_tensor

        def scale_down(tensor, secret_tensor):
            down_size = tf.random_uniform([1], 503, 512, dtype=tf.int32)[0]
            tensor = tf.random_crop(tensor, [self.batch_size, down_size, down_size, 1], seed=2)
            tensor = tf.image.resize_images(tensor, [512, 512])

            secret_tensor = tf.random_crop(secret_tensor, [self.batch_size, down_size, down_size, 1], seed=2)
            secret_tensor = tf.image.resize_images(secret_tensor, [512, 512])

            return tensor, secret_tensor

        def rotate(tensor, secret_tensor, angle=0.):
            if angle == 0.:
                angle = tf.random_uniform([1], math.radians(1), math.radians(3), dtype=tf.float32)
            tensor = tf.contrib.image.rotate(tensor, angle)
            secret_tensor = tf.contrib.image.rotate(secret_tensor, angle)
            return tensor, secret_tensor

        def add_noise(tensor, secret_tensor):
            random =tf.random_normal(shape=tf.shape(tensor), mean=0.0, stddev=std, dtype=tf.float32)
            tensor = tensor + random
            secret_tensor = secret_tensor + random
            return tensor, secret_tensor

        def translate(tensor, secret_tensor):
            size = tf.random_uniform([1], 0, 3, dtype=tf.float32)[0]
            tensor = tf.contrib.image.translate(tensor, [size, size])
            secret_tensor = tf.contrib.image.translate(secret_tensor, [size, size])
            return tensor, secret_tensor

        if mode == 'test':
            # stego_noise, secret_noise = rotate(tensor, secret_tensor, angle=math.radians(3))
            stego_noise, secret_noise = rotate(tensor, secret_tensor, angle=math.radians(10))
            # stego_noise, secret_noise = translate(tensor, secret_tensor)
            # stego_noise, secret_noise = scale_down(tensor, secret_tensor)
            return stego_noise, secret_noise

        if mode == 'train':
            with tf.variable_scope("transform_layer"):
                stego_noise = tensor
                secret_noise = secret_tensor
                # stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.7, lambda : add_noise(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : rotate(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : translate(stego_noise, secret_noise), lambda : (stego_noise, secret_noise))
                stego_noise, secret_noise = tf.cond(tf.random_uniform([1])[0] > 0.5, lambda : scale_up(stego_noise, secret_noise), lambda :scale_down(stego_noise, secret_noise))
                return stego_noise, secret_noise

        if mode == 'None':
            return tensor, secret_tensor
    def get_tensor_to_img_op(self,tensor):
        with tf.variable_scope("",reuse=True):
            return tf.clip_by_value(tensor,0,1)
            # return tf.clip_by_value(tensor,0,255)

    def prepare_training_graph(self,secret_tensor,cover_tensor,global_step_tensor):
        y_output, hidden = self.get_hiding_network_op(cover_tensor=cover_tensor, secret_tensor=secret_tensor, is_training=True)
        y_output_transformed, secret_tensor_transformed = self.get_noise_layer_op(y_output, secret_tensor, mode='train')
        reveal_output_op = self.get_reveal_network_op(y_output_transformed, is_training=True)
        fake_logits, _ = self.get_discriminator_pred_op(hidden, is_training=True, reuse=False)
        real_logits, _ = self.get_discriminator_pred_op(cover_tensor, is_training=True, reuse=True)

        D_final_loss, G_final_loss, D_loss, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
            self.get_loss_op(secret_tensor_transformed,reveal_output_op,cover_tensor,hidden, fake_logits, real_logits)

        global_variables = tf.global_variables()
        gan_varlist = [i for i in global_variables if i.name.startswith('Discriminator')]
        en_de_code_varlist = [i for i in global_variables if i not in gan_varlist]

        update_ops = tf.get_collection(tf.GraphKeys.UPDATE_OPS)
        with tf.control_dependencies(update_ops):
            D_minimize_op = tf.train.AdamOptimizer(self.learning_rate).minimize(D_final_loss, var_list=gan_varlist, global_step=global_step_tensor)
            G_minimize_op = tf.train.AdamOptimizer(self.learning_rate).minimize(G_final_loss, var_list=en_de_code_varlist, global_step=global_step_tensor)

        tf.summary.scalar('learning_rate', self.learning_rate)
        tf.summary.scalar('D_final_loss', D_final_loss)
        tf.summary.scalar('G_final_loss', G_final_loss)
        tf.summary.scalar('D_loss', D_loss)
        tf.summary.scalar('G_loss', G_loss)
        tf.summary.scalar('secret_mse', secret_mse)
        tf.summary.scalar('cover_mse', cover_mse)
        tf.summary.scalar('secret_ssim', secret_ssim)
        tf.summary.scalar('cover_ssim', cover_ssim)

        tf.summary.image('secret',self.get_tensor_to_img_op(secret_tensor_transformed),max_outputs=1,family='train')
        tf.summary.image('cover',self.get_tensor_to_img_op(cover_tensor),max_outputs=1,family='train')
        tf.summary.image('hidden',self.get_tensor_to_img_op(hidden),max_outputs=1,family='train')
        tf.summary.image('hidden_transform',self.get_tensor_to_img_op(y_output_transformed),max_outputs=1,family='train')
        tf.summary.image('revealed',self.get_tensor_to_img_op(reveal_output_op),max_outputs=1,family='train')

        merged_summary_op = tf.summary.merge_all()

        return D_minimize_op, G_minimize_op, D_final_loss, G_final_loss, merged_summary_op, secret_mse, cover_mse, secret_ssim, cover_ssim

    def prepare_test_graph(self,secret_tensor,cover_tensor):
        y_output, hidden = self.get_hiding_network_op(cover_tensor=cover_tensor,secret_tensor=secret_tensor, is_training=False)
        y_output_transformed, secret_transformed = self.get_noise_layer_op(y_output, secret_tensor, mode='test')
        reveal_output_op = self.get_reveal_network_op(y_output_transformed, is_training=False)

        fake_logits, fake_prob = self.get_discriminator_pred_op(hidden, is_training=False, reuse=False)
        real_logits, real_prob = self.get_discriminator_pred_op(cover_tensor, is_training=False, reuse=True)

        D_final_loss, G_final_loss, D_loss, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
            self.get_loss_op(secret_transformed,reveal_output_op,cover_tensor,hidden, fake_logits, real_logits, test=True)

        return hidden, reveal_output_op, y_output_transformed, secret_transformed, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim

    def save_chkp(self,path):
        global_step = self.sess.run(self.global_step_tensor)
        self.saver.save(self.sess,path,global_step)

    def load_chkp(self,path):
        self.saver.restore(self.sess,path)
        print("LOADED")

    def train(self):

        with tf.device('/cpu:0'):

            segdl = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_val/',
                                            '/mnt/2T/moliq/Documents/binaryimages/', self.batch_size,
                                            (512, 512), (512, 512),
                                            'dataset/imagenet_train.txt', split='train')

            segdl_val = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_val/',
                                            '/mnt/2T/moliq/Documents/binaryimages/', self.batch_size,
                                            (512, 512), (512, 512),
                                            'dataset/imagenet_train.txt', split='val')


        steps_per_epoch = segdl.data_len / segdl.batch_size
        steps_per_epoch_val = segdl_val.data_len / segdl_val.batch_size

        self.learning_rate = tf.train.exponential_decay(self.starter_learning_rate, self.global_step_tensor,steps_per_epoch*8, 0.1, staircase=True)

        # self.train_op_G, G_final_loss, self.summary_op, self.secret_mse, self.cover_mse, self.secret_ssim, self.cover_ssim = \
        #     self.prepare_training_graph(self.secret_yuv, self.cover_yuv, self.global_step_tensor)

        self.train_op_D, self.train_op_G, D_final_loss, G_final_loss, self.summary_op, self.secret_mse, self.cover_mse, self.secret_ssim, self.cover_ssim = \
            self.prepare_training_graph(self.secret_tensor, self.cover_tensor, self.global_step_tensor)

        if not os.path.exists(self.log_path):
            os.makedirs(self.log_path)

        self.writer = tf.summary.FileWriter(self.log_path, self.sess.graph)
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(max_to_keep=50)

        # saver1 = tf.train.Saver()
        # loader1 = tf.train.latest_checkpoint('logs/0930-1654')
        # saver1.restore(self.sess, loader1)
        # print('loaded pretrained model', loader1)
        #
        #exclude_vars = ['beta1_power:0', 'beta2_power:0', 'global_step:0']
        #restore_variables = [i for i in tf.global_variables() if not i.name in exclude_vars]
        #saver1 = tf.train.Saver(var_list=restore_variables)
        #loader1 = tf.train.latest_checkpoint('logs/0924-1627')
        #saver1.restore(self.sess, loader1)
        #print('loaded pretrained model', loader1)

        # loader = tf.train.latest_checkpoint('logs/1223-1124')
        # loader = tf.train.latest_checkpoint('logs/0101-1053')
        loader = tf.train.latest_checkpoint('logs/0106-0058')
        # global_variables = tf.global_variables()
        # encode_decode_varlist = [i for i in global_variables if not i.name.startswith('Discriminator')]
        # exclude_vars = ['beta1_power:0', 'beta2_power:0', 'global_step:0', 'beta1_power_1:0', 'beta2_power_1:0']
        # restore_variables = [i for i in encode_decode_varlist if not i.name in exclude_vars]
        # custom_saver = tf.train.Saver(var_list=restore_variables)
        custom_saver = tf.train.Saver()
        custom_saver.restore(self.sess, loader)
        print('load model %s' % loader)
        #
        #
        # # # # global_variables = tf.global_variables()
        # gan_varlist = [i for i in global_variables if i.name.startswith('Discriminator')]
        # gan_varlist = [i for i in gan_varlist if not i.name.endswith('Adam:0')]
        # gan_varlist = [i for i in gan_varlist if not i.name.endswith('Adam_1:0')]
        # gan_varlist = [i for i in gan_varlist if not i.name.endswith('weights:0')]
        # # # gan_varlist_dict = {i.name[:-2]:i for i in gan_varlist}
        # gan_saver = tf.train.Saver(var_list=gan_varlist)
        # gan_saver.restore(self.sess, 'logs/0925-1654-boss_gan/-130200')
        # print('load model %s' % 'logs/0925-1654-boss_gan/-130200')



        for epoch in range(1, 1+self.epoches):
            with tf.device('/cpu:0'):


                segdl = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_val/',
                                            '/mnt/2T/moliq/Documents/binaryimages/', self.batch_size,
                                            (512, 512), (512, 512),
                                            'dataset/imagenet_train.txt', split='train')

                segdl_val = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_test/',
                                                '/mnt/2T/moliq/Documents/binaryimages/', self.batch_size,
                                                (512, 512), (512, 512),
                                                'dataset/watermark_test.txt', split='val')


                iterator = Iterator.from_structure(segdl.data_tr.output_types, segdl.data_tr.output_shapes)
                iterator_val = Iterator.from_structure(segdl_val.data_tr.output_types, segdl_val.data_tr.output_shapes)
                next_batch = iterator.get_next()
                next_batch_val = iterator_val.get_next()
                training_init_op = iterator.make_initializer(segdl.data_tr)
                training_init_op_val = iterator_val.make_initializer(segdl_val.data_tr)

            print('epoch %d'%epoch)
            self.sess.run(training_init_op)
            for i in range(steps_per_epoch):
                try:
                    cover_tensor, secret_tensor = self.sess.run(next_batch)
                except:
                    continue
                _, G_loss, secret_mse, cover_mse, secret_ssim, cover_ssim, summary, global_step = \
                    self.sess.run([self.train_op_G, G_final_loss, self.secret_mse, self.cover_mse, self.secret_ssim, self.cover_ssim, self.summary_op, self.global_step_tensor],
                    feed_dict={self.secret_tensor: secret_tensor, self.cover_tensor: cover_tensor})

                if i % 5 == 0:
                    _,  D_loss, summary = \
                        self.sess.run([self.train_op_D, D_final_loss, self.summary_op],
                        feed_dict={self.secret_tensor: secret_tensor,self.cover_tensor: cover_tensor})
                    # self.writer.add_summary(summary, global_step)

                if i % 10 == 0:
                    self.writer.add_summary(summary, global_step)

                if i % 100 == 0:
                    print('Epoch [{}/{}]  Step [{}/{}] G_final_Loss {:.4f} D_final_Loss {:.4f} encoder_ssim {:.4f} encoder_mse {:.4f}'
                          '  decoder_ssim {:.4f}  decoder_mse {:.4f} '.format(
                        epoch, self.epoches, i, steps_per_epoch, G_loss, D_loss,
                        cover_ssim, cover_mse, secret_ssim, secret_mse ))

            # run validation
            self.sess.run(training_init_op_val)
            D_loss_val_this_epoch = []
            # G_loss_val_this_epoch = []
            secret_ssim_this_epoch = []
            secret_mse_this_epoch = []
            cover_ssim_this_epoch = []
            cover_mse_this_epoch = []
            for i in range(steps_per_epoch_val/10):
                cover_tensor_val, secret_tensor_val = self.sess.run(next_batch_val)
                D_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
                    self.sess.run([D_final_loss, self.secret_mse,self.cover_mse, self.secret_ssim, self.cover_ssim],
                                                                feed_dict={self.secret_tensor: secret_tensor_val,
                                                                self.cover_tensor: cover_tensor_val})
                D_loss_val_this_epoch.append(D_loss)
                # G_loss_val_this_epoch.append(G_loss)
                secret_ssim_this_epoch.append(secret_ssim)
                secret_mse_this_epoch.append(secret_mse)
                cover_ssim_this_epoch.append(cover_ssim)
                cover_mse_this_epoch.append(cover_mse)
            mean_D_loss_val_this_epoch = sum(D_loss_val_this_epoch) / len(D_loss_val_this_epoch)
            # mean_G_loss_val_this_epoch = sum(G_loss_val_this_epoch) / len(G_loss_val_this_epoch)
            mean_secret_ssim_this_epoch = sum(secret_ssim_this_epoch) / len(secret_ssim_this_epoch)
            mean_secret_mse_this_epoch = sum(secret_mse_this_epoch) / len(secret_mse_this_epoch)
            mean_cover_ssim_this_epoch = sum(cover_ssim_this_epoch) / len(cover_ssim_this_epoch)
            mean_cover_mse_this_epoch = sum(cover_mse_this_epoch) / len(cover_mse_this_epoch)
            # print('global step: %d, validation loss: %.4f'%(global_step, mean_loss_val_this_epoch))
            print('VALIDATION Epoch {} global step {} mean_D_Loss {:.4f} valid_encoder_ssim {:.4f} valid_decoder_ssim {:.4f}, valid_encoder_mse {:.4f} valid_decoder_mse {:.4f}'.format(
                epoch, global_step, mean_D_loss_val_this_epoch, mean_cover_ssim_this_epoch, mean_secret_ssim_this_epoch, mean_cover_mse_this_epoch, mean_secret_mse_this_epoch))

            # self.save_chkp(self.log_path+'%d_%.3f.ckpt'%(epoch, mean_loss_val_this_epoch))
            self.save_chkp(self.log_path)


    def test_performance(self, log_path):

        # hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
        #                         self.prepare_test_graph(self.secret_yuv, self.cover_yuv)
        hiding_output_op, reveal_output_op, y_output_transformed_op, secret_transformed_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = \
            self.prepare_test_graph(self.secret_tensor, self.cover_tensor)

        if os.path.exists(log_path+'.meta'):
            loader = log_path
        else:
            loader = tf.train.latest_checkpoint(log_path)
        # loader = 'logs/0925-1654/-98700'

        # from tensorflow.python.tools import inspect_checkpoint as chkp
        # chkp.print_tensors_in_checkpoint_file(loader, tensor_name='', all_tensors=True)
        # from inspect_checkpoint import print_tensors_in_checkpoint_file
        # print_tensors_in_checkpoint_file(loader, tensor_name='', all_tensors=True)

        # variables = [i for i in tf.global_variables() if i.name not in ['global_step:0']]
        # saver_variables_dict = {value.name[:-2]:value for value in variables}
        # custom_saver = tf.train.Saver(saver_variables_dict)
        # custom_saver.restore(self.sess, loader)
        # print('load model %s'%loader)

        # self.saver = tf.train.Saver(var_list=tf.global_variables())
        global_variables = tf.global_variables()
        gan_varlist = [i for i in global_variables if not i.name.startswith('Discriminator')]
        self.sess.run(tf.global_variables_initializer())
        # self.saver = tf.train.Saver(var_list=gan_varlist)
        self.saver = tf.train.Saver()
        self.saver.restore(self.sess, loader)
        print('load model %s'%loader)

        with tf.device('/cpu:0'):

            segdl_val = WatermarkDataLoader('/mnt/4T/moliq/moliq_imagenet/imagenet/ILSVRC2012_img_test/',
                                            '/mnt/2T/moliq/Documents/binaryimages/', self.batch_size,
                                            (512, 512), (512, 512),
                                            'dataset/watermark_test.txt', split='val')

            iterator_val = Iterator.from_structure(segdl_val.data_tr.output_types, segdl_val.data_tr.output_shapes)
            next_batch_val = iterator_val.get_next()
            training_init_op_val = iterator_val.make_initializer(segdl_val.data_tr)

        steps_per_epoch_val = segdl_val.data_len / segdl_val.batch_size

        loss_val_this_epoch = []
        secret_mse_val_this_epoch = []
        cover_mse_val_this_epoch = []
        secret_ssim_this_epoch = []
        cover_ssim_this_epoch = []


        self.sess.run(training_init_op_val)

        # self.saver.restore(self.sess, loader)
        # print('load model %s'%loader)


        for i in range(steps_per_epoch_val):
        # for i in range(5):
            cover_tensor_val, secret_tensor_val = self.sess.run(next_batch_val)
            stego, secret_reveal, y_output_transformed, secret_transformed, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value = \
                self.sess.run(
                    [hiding_output_op, reveal_output_op, y_output_transformed_op, secret_transformed_op, G_final_loss,
                     secret_mse, cover_mse, secret_ssim, cover_ssim],
                    feed_dict={self.secret_tensor: secret_tensor_val,
                               self.cover_tensor: cover_tensor_val})

            cover_names = segdl_val.imgs_files[i*segdl_val.batch_size:(i+1)*segdl_val.batch_size]
            secret_names = segdl_val.labels_files[i*segdl_val.batch_size:(i+1)*segdl_val.batch_size]

            loss_val_this_epoch.append(loss_value)
            secret_mse_val_this_epoch.append(secret_mse_value)
            cover_mse_val_this_epoch.append(cover_mse_value)
            secret_ssim_this_epoch.append(secret_ssim_value)
            cover_ssim_this_epoch.append(cover_ssim_value)
            # if i >= 250 and i < 500:
            # if i < 20:
            #     save_test_images(cover_names, secret_names, cover_tensor_val, secret_transformed, stego, secret_reveal,log_path)
            if i < 375:
                save_stegnalysis_images(cover_names, secret_names, cover_tensor_val, secret_transformed, stego, secret_reveal, log_path)

            if i%50 == 0:
                print('%d loss %.3f secret_mse %.3f cover_mse %.3f secret_ssim %.3f cover_ssim %.3f'%(i, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value))

        mean_loss_val_this_epoch = np.mean(loss_val_this_epoch)
        mean_secret_mse_val_this_epoch = np.mean(secret_mse_val_this_epoch)
        mean_cover_mse_val_this_epoch = np.mean(cover_mse_val_this_epoch)
        mean_secret_ssim_this_epoch = np.mean(secret_ssim_this_epoch)
        mean_cover_ssim_this_epoch = np.mean(cover_ssim_this_epoch)
        psnr_cover = psnr(mean_cover_mse_val_this_epoch)
        psnr_secret = psnr(mean_secret_mse_val_this_epoch)

        print('validation loss: %.4f' % mean_loss_val_this_epoch)
        print('secret mse: %.4f' % mean_secret_mse_val_this_epoch)
        print('cover mse : %.4f' % mean_cover_mse_val_this_epoch)
        print('secret ssim: %.4f' % mean_secret_ssim_this_epoch)
        print('cover ssim: %.4f' % mean_cover_ssim_this_epoch)
        print('secret psnr: %.4f' % psnr_secret)
        print('cover psnr: %.4f' % psnr_cover)

    def test_one_image(self, log_path, cover_image, secret_image):

        hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim, fake_prob, real_prob = \
            self.prepare_test_graph(self.secret_tensor, self.cover_tensor)

        loader = tf.train.latest_checkpoint(log_path)

        global_variables = tf.global_variables()
        gan_varlist = [i for i in global_variables if not i.name.startswith('Discriminator')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=gan_varlist)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        stego, secret_reveal, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value, fake_prob_value, real_prob_value = \
            self.sess.run(
                [hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim,
                 fake_prob, real_prob],
                feed_dict={self.secret_tensor: secret_image,
                           self.cover_tensor: cover_image})

        stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
        secret_reveal = (np.mean(secret_reveal, axis=-1) > 0.5).astype(np.uint8)
        return stego, secret_reveal

    def get_stego(self, log_path, cover_image, secret_image):
        hidden = self.get_hiding_network_op(cover_tensor=self.cover_tensor,secret_tensor=self.secret_tensor, is_training=False)

        loader = tf.train.latest_checkpoint(log_path)
        global_variables = tf.global_variables()
        encode_vars = [i for i in global_variables if i.name.startswith('encode')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=encode_vars)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        stego = self.sess.run(
                hidden,
                feed_dict={self.secret_tensor: secret_image,
                           self.cover_tensor: cover_image})

        stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
        return stego

    def get_secret(self, log_path, stego_image):

        reveal_output_op = self.get_reveal_network_op(self.stego_tensor, is_training=False)

        loader = tf.train.latest_checkpoint(log_path)
        global_variables = tf.global_variables()
        decode_vars = [i for i in global_variables if i.name.startswith('decode')]
        self.sess.run(tf.global_variables_initializer())
        self.saver = tf.train.Saver(var_list=decode_vars)
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)

        secret_reveal = self.sess.run(reveal_output_op, feed_dict={self.stego_tensor: stego_image})
        secret_reveal = (np.mean(secret_reveal, axis=-1) > 0.5).astype(np.uint8)
        return secret_reveal

    def test_paper(self, log_path, directory):
        hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim = self.prepare_test_graph(self.secret_tensor, self.cover_tensor)
        loader = tf.train.latest_checkpoint(log_path)
        self.saver = tf.train.Saver()
        self.saver.restore(self.sess, loader)
        print('load model %s' % loader)
        image_names = os.listdir(directory)
        cover_images_names = [i for i in image_names if i.endswith('0.png')]
        for i, cover_name in enumerate(cover_images_names):
            cover = plt.imread(os.path.join(directory, cover_name))
            secret = plt.imread(os.path.join(directory, cover_name.replace('_0', '_2')))
            # cover = (cover/255.).astype(np.float32)
            # secret = (secret/255.).astype(np.float32)
            cover = np.expand_dims(cover, 0)
            secret = np.expand_dims(secret, 0)

            stego, secret_reveal, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value = \
                self.sess.run(
                    [hiding_output_op, reveal_output_op, G_final_loss, secret_mse, cover_mse, secret_ssim, cover_ssim],
                    feed_dict={self.secret_tensor: secret,
                               self.cover_tensor: cover})

            print('%d loss %.3f secret_mse %.3f cover_mse %.3f secret_ssim %.3f cover_ssim %.3f' % (
            i, loss_value, secret_mse_value, cover_mse_value, secret_ssim_value, cover_ssim_value))

            stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
            # stego = (((stego - stego.min()) * 255) / (stego.max() - stego.min())).astype(np.uint8)
            secret_reveal = (((secret_reveal - secret_reveal.min()) * 255) / (
                    secret_reveal.max() - secret_reveal.min())).astype(np.uint8)
            plt.imsave(os.path.join(directory, cover_name[:-4]+'_us_voc.png'), stego.squeeze())
            plt.imsave(os.path.join(directory, cover_name[:-5]+'2_us_voc.png'), secret_reveal.squeeze())

if __name__ == '__main__':
    train_model = Model()
    # train_model.train()
    # train_model.test_performance('logs/1231-1627')
    # train_model.test_performance('logs/0101-1053/-45000')
    # train_model.test_performance('logs/0106-0058/')
    train_model.test_performance('logs/0106-1009/')



