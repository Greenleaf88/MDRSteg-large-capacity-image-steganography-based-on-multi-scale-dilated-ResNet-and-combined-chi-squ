# -*- coding: utf-8 -*-
import os
import numpy as np
import glob
import cv2
import matplotlib.pyplot as plt
# from tensorflow.data import Iterator
# from Dataset import SegDataLoader

def visulize_npy_result(log_dir):
    import tensorflow as tf
    save_dir = os.path.join(log_dir, 'test')
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    secret_revealed = np.load(os.path.join(log_dir, 'test_secrets_revealed.npy'))
    secret_revealed = np.reshape(secret_revealed, (secret_revealed.shape[0]*secret_revealed.shape[1], 256, 256, 1))
    # secret_revealed = (((secret_revealed - secret_revealed.min()) * 255) / (secret_revealed.max() - secret_revealed.min())).astype(np.uint8)
    stegos = np.load(os.path.join(log_dir, 'test_stegos.npy'))
    stegos = np.reshape(stegos, (stegos.shape[0]*stegos.shape[1], 256, 256, 3))
    # stegos = (((stegos - stegos.min()) * 255) / (stegos.max() - stegos.min())).astype(np.uint8)


    with tf.device('/cpu:0'):
        segdl_val = SegDataLoader('/home/moliq/Documents/VOC2012/JPEGImages/', 1, (256, 256), (256, 256),
                                  'voc_valid.txt', split='val')
        iterator_val = Iterator.from_structure(segdl_val.data_tr.output_types, segdl_val.data_tr.output_shapes)
        next_batch_val = iterator_val.get_next()
        training_init_op_val = iterator_val.make_initializer(segdl_val.data_tr)

    with tf.Session() as sess:
        sess.run(training_init_op_val)
        for i in range(segdl_val.data_len):
            print('%d / %d'%(i, segdl_val.data_len))
            cover_name = segdl_val.imgs_files[i]
            secret_name = segdl_val.labels_files[i]
            common_name = os.path.basename(cover_name)[:-4] + '+' + os.path.basename(secret_name)[:-4]
            cover_image, secret_image = sess.run(next_batch_val)
            stego_i = stegos[i]
            stego_i = (((stego_i - stego_i.min()) * 255) / (stego_i.max() - stego_i.min())).astype(np.uint8)
            secret_revealed_i = secret_revealed[i]
            secret_revealed_i = (((secret_revealed_i - secret_revealed_i.min()) * 255) / (secret_revealed_i.max() - secret_revealed_i.min())).astype(np.uint8)

            cv2.imwrite(os.path.join(save_dir, common_name+'_cover.jpg'), np.squeeze(cover_image*255).astype(np.uint8)[:,:,::-1])
            cv2.imwrite(os.path.join(save_dir, common_name+'_secret.jpg'), np.squeeze(secret_image*255).astype(np.uint8))
            cv2.imwrite(os.path.join(save_dir, common_name+'_stego.jpg'), np.squeeze(stego_i)[:,:,::-1])
            cv2.imwrite(os.path.join(save_dir, common_name+'_secret_reveal.jpg'), np.squeeze(secret_revealed_i))

    print('Done!')

def write_to_pgm(image, fileout):
    width, height= image.shape
    pgmHeader = 'P5' + ' ' + str(width) + ' ' + str(height) + ' ' + str(255) + '\n'
    pgmHeader_byte = bytearray(pgmHeader, 'utf-8')
    fout = open(fileout, 'wb')
    # write the header to the file
    fout.write(pgmHeader_byte)
    for j in range(height):
        bnd = list(image[j, :])
        fout.write(bytearray(bnd))
    fout.close()

def save_test_images(cover_names, secret_names, covers, secrets, stegos, secret_reveals, log_dir):
    # from utils import yuv2rgb_np
    save_dir = os.path.join(log_dir, 'test_watermark_origin')
    # save_dir = os.path.join(log_dir, 'test_stegonalysis')
    # save_dir0 = os.path.join(log_dir, 'test_cover')
    # save_dir = os.path.join(log_dir, 'test_stego')
    #save_dir2 = os.path.join(log_dir, 'test_pgm_b')
    #save_dir3 = os.path.join(log_dir, 'test_pgm_r')
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
        # os.makedirs(save_dir0)
        #os.makedirs(save_dir2)
        #os.makedirs(save_dir3)
    batch_size = covers.shape[0]
    # stegos = yuv2rgb_np(stegos)
    # secret_reveals = yuv2rgb_np(secret_reveals)
    for i in range(batch_size):
        cover = covers[i]
        secret = secrets[i]
        stego = stegos[i]
        secret_reveal = secret_reveals[i]
        cover_name = cover_names[i]
        secret_name = secret_names[i]
        common_name = os.path.basename(cover_name)[:-4] + '+' + os.path.basename(secret_name)[:-4]

        # stego = (((stego - stego.min()) * 255) / (stego.max() - stego.min())).astype(np.uint8)
        # cover_g = (np.clip(cover, 0, 1)*255).astype(np.uint8)[..., 1]
        # stego_g = (np.clip(stego, 0, 1)*255).astype(np.uint8)[..., 1]
        # write_to_pgm(np.squeeze(cover_g), os.path.join(save_dir0, os.path.basename(cover_name)[:-4]+'.pgm'))
        # write_to_pgm(np.squeeze(stego_g), os.path.join(save_dir, os.path.basename(cover_name)[:-4]+'.pgm'))

        # cover_gray = cv2.cvtColor((np.clip(cover, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
        # stego_gray = cv2.cvtColor((np.clip(stego, 0, 1) * 255).astype(np.uint8), cv2.COLOR_RGB2GRAY)
        # write_to_pgm(np.squeeze(cover_gray), os.path.join(save_dir0, os.path.basename(cover_name)[:-4] + '.pgm'))
        # write_to_pgm(np.squeeze(stego_gray), os.path.join(save_dir, os.path.basename(cover_name)[:-4] + '.pgm'))

        cover = (np.clip(cover, 0, 1) * 255).astype(np.uint8)
        stego = (np.clip(stego, 0, 1) * 255).astype(np.uint8)
        # cv2.imwrite(os.path.join(save_dir, os.path.basename(cover_name)[:-4] + 'png'),
        #            np.squeeze(cover)[:, :, ::-1])
        # cv2.imwrite(os.path.join(save_dir, os.path.basename(cover_name)[:-4] + 'png'),
        #            np.squeeze(stego)[:, :, ::-1])
        #stego_b = (np.clip(stego, 0, 1)*255).astype(np.uint8)[..., 2]
        #stego_r = (np.clip(stego, 0, 1)*255).astype(np.uint8)[..., 0]
        # secret = (secret[:,:,0] > 0.5).astype(np.uint8)
        secret_reveal = (secret_reveal[:,:,0] > 0.5).astype(np.uint8)*255
        # secret_reveal = (np.clip(secret_reveal, 0, 1) * 255).astype(np.uint8)
        #write_to_pgm(np.squeeze(stego_b), os.path.join(save_dir2, os.path.basename(cover_name)))
        #write_to_pgm(np.squeeze(stego_r), os.path.join(save_dir3, os.path.basename(cover_name)))
        cv2.imwrite(os.path.join(save_dir, common_name + '_cover.png'),
                   np.squeeze(cover).astype(np.uint8)[:, :, ::-1])
        cv2.imwrite(os.path.join(save_dir, common_name + '_secret.png'),
                   np.squeeze(secret * 255).astype(np.uint8))
        cv2.imwrite(os.path.join(save_dir, common_name + '_cover_hidden.png'), np.squeeze(stego)[:, :, ::-1])
        cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.png'), np.squeeze(secret_reveal))
        # cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.png'), np.squeeze(secret_reveal))


def save_stegnalysis_images(cover_names, secret_names, covers, secrets, stegos, secret_reveals, log_dir):
    save_dir0 = os.path.join(log_dir, 'test_stegonalysis', 'cover')
    save_dir1 = os.path.join(log_dir, 'test_stegonalysis', 'stego')
    if not os.path.exists(save_dir0):
        os.makedirs(save_dir0)
        os.makedirs(save_dir1)

    batch_size = covers.shape[0]
    for i in range(batch_size):
        cover = covers[i]
        # secret = secrets[i]
        stego = stegos[i]
        # secret_reveal = secret_reveals[i]
        cover_name = cover_names[i]
        secret_name = secret_names[i]
        common_name = os.path.basename(cover_name)[:-4] + '+' + os.path.basename(secret_name)[:-4]

        cover =  np.squeeze((np.clip(cover, 0, 1) * 255).astype(np.uint8))
        stego =  np.squeeze((np.clip(stego, 0, 1) * 255).astype(np.uint8))

        cover_gray_image = cv2.cvtColor(cover, cv2.COLOR_RGB2GRAY)
        stego_gray_image = cv2.cvtColor(stego, cv2.COLOR_RGB2GRAY)

        # secret_reveal = (secret_reveal[:,:,0] > 0.5).astype(np.uint8)*255
        # secret_reveal = (np.clip(secret_reveal, 0, 1) * 255).astype(np.uint8)

        write_to_pgm(cover_gray_image, os.path.join(save_dir0, common_name + '_cover.pgm'), )
        write_to_pgm(stego_gray_image, os.path.join(save_dir1, common_name + '_cover_hidden.pgm'), )

        # cv2.imwrite(os.path.join(save_dir0, common_name + '_cover.png'), cover_gray_image)
        # cv2.imwrite(os.path.join(save_dir, common_name + '_secret.png'),
        #            np.squeeze(secret * 255).astype(np.uint8))
        # cv2.imwrite(os.path.join(save_dir1, common_name + '_cover_hidden.png'), stego_gray_image)
        # cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.jpg'), np.squeeze(secret_reveal))
        # cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.png'), np.squeeze(secret_reveal))

def save_test_images_without_stego(cover_names, secret_names, covers, secrets, secret_reveals, log_dir):
    save_dir = os.path.join(log_dir, 'test_watermark_origin')
    if not os.path.exists(save_dir):
        os.makedirs(save_dir)
    batch_size = covers.shape[0]

    for i in range(batch_size):
        cover = covers[i]
        secret = secrets[i]
        secret_reveal = secret_reveals[i]
        cover_name = cover_names[i]
        secret_name = secret_names[i]
        common_name = os.path.basename(cover_name)[:-4] + '+' + os.path.basename(secret_name)[:-4]

        cover = (np.clip(cover, 0, 1) * 255).astype(np.uint8)

        # secret = (secret[:,:,0] > 0.5).astype(np.uint8)
        secret_reveal = (secret_reveal[:,:,0] > 0.5).astype(np.uint8)
        # secret_reveal = (np.clip(secret_reveal, 0, 1) * 255).astype(np.uint8)
        #write_to_pgm(np.squeeze(stego_b), os.path.join(save_dir2, os.path.basename(cover_name)))
        #write_to_pgm(np.squeeze(stego_r), os.path.join(save_dir3, os.path.basename(cover_name)))
        cv2.imwrite(os.path.join(save_dir, common_name + '_stego.png'),
                   np.squeeze(cover).astype(np.uint8))
        cv2.imwrite(os.path.join(save_dir, common_name + '_secret.png'),
                   np.squeeze(secret * 255).astype(np.uint8))
        cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.png'), np.squeeze(secret_reveal* 255))
        # cv2.imwrite(os.path.join(save_dir, common_name + '_secret_reveal.png'), np.squeeze(secret_reveal))

def plot_validation_scores(log_path):
    log = open(log_path, 'r').readlines()
    scores = [i.strip().split(' ') for i in log if i.startswith('VALIDATION Epoch')]

    # d_loss = [float(i[-7]) for i in scores]
    # g_loss = [float(i[-5]) for i in scores]
    en_sim = [float(i[-7]) for i in scores]
    de_sim = [float(i[-5][:-1]) for i in scores]

    plt.figure()
    n = len(en_sim)
    x = np.linspace(1, n, n, dtype=np.int16)

    l1, = plt.plot(x, en_sim, label='line', color='red', linewidth=1.0)
    l3, = plt.plot(x, de_sim, label='line', color='blue', linewidth=1.0)

    plt.xlabel('epoch')
    plt.ylabel('simm')
    # plt.title('Google-{:s}'.format(name))
    plt.legend(handles=[l1, l3], labels=['cover', 'secret'],
               loc='best')
    plt.savefig(os.path.join(os.path.dirname(log_path), '{:s}_result.jpg'.format('ssim')))

    # plt.figure()
    # n = len(en_sim)
    # x = np.linspace(1, n, n)
    # l2, = plt.plot(x, d_loss, label='parabola', color='red', linewidth=1.0, linestyle='--')
    # l4, = plt.plot(x, g_loss, label='parabola', color='blue', linewidth=1.0, linestyle='--')
    #
    # plt.xlabel('epoch')
    # plt.ylabel('loss')
    #
    # plt.legend(handles=[l2, l4], labels=['d_loss', 'g_loss'],
    #            loc='best')
    # plt.savefig(os.path.join(os.path.dirname(log_path), '{:s}_result.jpg'.format('loss')))


def plot_histogram(dirctory):
    image_names = os.listdir(dirctory)
    image_names = [i for i in image_names if 'residual_hidden' not in i]
    stego = [i for i in image_names if i.endswith('stego.jpg')]
    secret = [i for i in image_names if i.endswith('secret.jpg')]
    secret_reveal = [i for i in image_names if i.endswith('secret_reveal.jpg')]
    cover = [i for i in image_names if i.endswith('cover.jpg')]
    # stego_image = cv2.imread(stego[0])
    # secret_image = cv2.imread(secret[0])
    # secret_reveal_image = cv2.imread(secret_reveal[0])
    # cover_image = cv2.imread(cover[0])
    for i in [stego, secret, secret_reveal, cover]:
        plt.figure()
        name = i[0]
        image = cv2.imread(os.path.join(dirctory, name))
        fig = plt.hist(image.flatten(), bins=256, range=(0,255))
        plt.savefig(os.path.join(dirctory, name[:-4]+'_hist.jpg'))


def plot_residual(dirctory):
    image_names = os.listdir(dirctory)
    stego = [i for i in image_names if i.endswith('stego.jpg')]
    secret = [i for i in image_names if i.endswith('secret.jpg')]
    secret_reveal = [i for i in image_names if i.endswith('secret_reveal.jpg')]
    cover = [i for i in image_names if i.endswith('cover.jpg')]
    stego_image = cv2.imread(os.path.join(dirctory, stego[0]))
    secret_image = cv2.imread(os.path.join(dirctory, secret[0]))
    secret_reveal_image = cv2.imread(os.path.join(dirctory, secret_reveal[0]))
    cover_image = cv2.imread(os.path.join(dirctory, cover[0]))

    residual_hidden = np.abs(stego_image - cover_image)
    residual_reveal = np.abs(secret_image - secret_reveal_image)

    cv2.imwrite(os.path.join(dirctory, 'residual_hidden_X1.jpg'), residual_hidden)
    cv2.imwrite(os.path.join(dirctory, 'residual_reveal_X1.jpg'), residual_reveal)

    cv2.imwrite(os.path.join(dirctory, 'residual_hidden_X10.jpg'), residual_hidden*10)
    cv2.imwrite(os.path.join(dirctory, 'residual_reveal_X10.jpg'), residual_reveal*10)


def generate_hist_in_dirctory(dirctory):
    image_names = os.listdir(dirctory)
    image_names = [i for i in image_names if not i.endswith('hist.png')]
    image_names = [i for i in image_names if 'residual' not in i]
    for i,name in enumerate(image_names):
        print(i)
        plt.figure()
        image = cv2.imread(os.path.join(dirctory, name))
        fig = plt.hist(image.flatten(), bins=256, range=(0,255))
        plt.savefig(os.path.join(dirctory, name[:-4]+'_hist.png'))

def generate_residual_in_dirctory(dirctory):
    image_names = os.listdir(dirctory)
    image_names = [i for i in image_names if not i.endswith('hist.png')]
    image_names = [i for i in image_names if 'residual' not in i]
    image_names.sort()
    for i in range(0, len(image_names), 4):
        name = image_names[i][:-4]
        image_group = image_names[i:i+4]
        stego = [i for i in image_group if i.endswith('cover_hidden.png')]
        secret = [i for i in image_group if i.endswith('secret.png')]
        secret_reveal = [i for i in image_group if i.endswith('secret_reveal.png')]
        cover = [i for i in image_group if i.endswith('cover.png')]
        stego_image = cv2.imread(os.path.join(dirctory, stego[0]))
        secret_image = cv2.imread(os.path.join(dirctory, secret[0]))
        secret_reveal_image = cv2.imread(os.path.join(dirctory, secret_reveal[0]))
        cover_image = cv2.imread(os.path.join(dirctory, cover[0]))

        residual_hidden = np.abs(np.float32(stego_image) - np.float32(cover_image)).astype(np.uint8)
        residual_reveal = np.abs(np.float32(secret_image) - np.float32(secret_reveal_image)).astype(np.uint8)

        cv2.imwrite(os.path.join(dirctory, name+'_residual_hidden_X1.png'), residual_hidden)
        cv2.imwrite(os.path.join(dirctory, name+'_residual_reveal_X1.png'), residual_reveal)
        cv2.imwrite(os.path.join(dirctory, name+'_residual_hidden_X5.png'), residual_hidden * 5)
        cv2.imwrite(os.path.join(dirctory, name+'_residual_reveal_X5.png'), residual_reveal * 5)
        cv2.imwrite(os.path.join(dirctory, name+'_residual_hidden_X10.png'), residual_hidden * 10)
        cv2.imwrite(os.path.join(dirctory, name+'_residual_reveal_X10.png'), residual_reveal * 10)




def read_image(data_path, hist=False, axis=1):
    stego = [i for i in data_path if i.endswith('stego.jpg')]
    secret = [i for i in data_path if i.endswith('secret.jpg')]
    secret_reveal = [i for i in data_path if i.endswith('secret_reveal.jpg')]
    cover = [i for i in data_path if i.endswith('cover.jpg')]

    stego_image = cv2.imread(stego[0])
    secret_image = cv2.imread(secret[0])
    secret_reveal_image = cv2.imread(secret_reveal[0])
    cover_image = cv2.imread(cover[0])
    out_image = np.concatenate([cover_image, stego_image, secret_image, secret_reveal_image], axis=axis)

    if hist:
        stego_hist = [i for i in data_path if i.endswith('stego_hist.jpg')]
        secret_hist = [i for i in data_path if i.endswith('secret_hist.jpg')]
        secret_reveal_hist = [i for i in data_path if i.endswith('secret_reveal_hist.jpg')]
        cover_hist = [i for i in data_path if i.endswith('cover_hist.jpg')]
        stego_hist_image = cv2.resize(cv2.imread(stego_hist[0]), (256,256))
        secret_hist_image = cv2.resize(cv2.imread(secret_hist[0]), (256,256))
        secret_hist_reveal_image = cv2.resize(cv2.imread(secret_reveal_hist[0]), (256,256))
        cover_hist_image = cv2.resize(cv2.imread(cover_hist[0]), (256,256))
        hist_image = np.concatenate([stego_hist_image, cover_hist_image, secret_hist_image, secret_hist_reveal_image], axis=axis)
        out_image = np.concatenate([out_image, hist_image], axis=1-axis)
        return out_image
    else:
        return out_image


def generate_model_result_on_voc_lfw():
    path_prefix = '/home/moliq/Documents/repos/TF_ISGAN/logs/0531-0954-lfw/test/Cristina_Torrens_Valero_0001+Janet_Chandler_0001'
    data_paths = glob.glob(path_prefix+'*')
    image1 = read_image(data_paths)

    path_prefix2 = '/home/moliq/周报/模型效果图/lfw/Lauren_Killian_0001+Gerhard_Schroeder_0020'
    data_paths2 = glob.glob(path_prefix2 + '*')
    image2 = read_image(data_paths2)

    path_prefix3 = '/home/moliq/周报/模型效果图/voc/2011_004474+2011_005623'
    data_paths3 = glob.glob(path_prefix3 + '*')
    image3 = read_image(data_paths3)

    path_prefix4 = '/home/moliq/Documents/repos/TF_ISGAN/logs/0528-1858-voc/test/2007_002400+2012_001027'
    data_paths4 = glob.glob(path_prefix4 + '*')
    image4 = read_image(data_paths4)

    final_image = np.concatenate([image1, image2, image3, image4], axis=0)
    cv2.imwrite('img/model_pred1.png', final_image)


def generate_model_result_on_imagenet():

    path_prefix = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/imagenet/1/'
    data_paths = glob.glob(path_prefix+'*')
    image1 = read_image(data_paths)

    path_prefix2 = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/imagenet/2/'
    data_paths2 = glob.glob(path_prefix2 + '*')
    image2 = read_image(data_paths2)

    path_prefix3 = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/imagenet/3/'
    data_paths3 = glob.glob(path_prefix3 + '*')
    image3 = read_image(data_paths3)

    # path_prefix4 = '/home/moliq/Documents/repos/TF_ISGAN/logs/0528-1858-voc/test/2007_002400+2012_001027'
    # data_paths4 = glob.glob(path_prefix4 + '*')
    # image4 = read_image(data_paths4)

    final_image = np.concatenate([image1, image2, image3], axis=0)
    cv2.imwrite('img/model_pred_imagenet.png', final_image)


def generate_model_hist_result():

    path_prefix = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/voc/1/'
    data_paths = glob.glob(path_prefix+'*')
    image1 = read_image(data_paths, hist=True, axis=0)

    path_prefix2 = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/voc/4/'
    data_paths2 = glob.glob(path_prefix2 + '*')
    image2 = read_image(data_paths2, hist=True, axis=0)

    path_prefix3 = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/lfw/3/'
    data_paths3 = glob.glob(path_prefix3 + '*')
    image3 = read_image(data_paths3, hist=True, axis=0)

    path_prefix4 = '/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/lfw/1/'
    data_paths4 = glob.glob(path_prefix4 + '*')
    image4 = read_image(data_paths4, hist=True, axis=0)

    final_image = np.concatenate([image1, image2, image3, image4], axis=1)
    cv2.imwrite('img/model_pred_hist.png', final_image)


def combine_images():
    pass


def add_text():
    # image_path = 'img/model_pred1.png'
    image_path = 'img/model_pred_imagenet.png'
    image = cv2.imread(image_path)
    zeros_shape = [50, image.shape[1], image.shape[-1]]
    zeros = np.ones(shape=zeros_shape, dtype=image.dtype)*255
    image = np.concatenate([zeros, image], axis=0)

    # font = cv2.FONT_HERSHEY_SIMPLEX
    # cv2.putText(image, 'cover', (0, 0), font, 1, (0, 0, 0), 1)
    # cv2.imwrite(image_path.split('.')[0]+'_text.png', image)

    from PIL import ImageFont, ImageDraw, Image

    # Convert to PIL Image
    cv2_im_rgb = cv2.cvtColor(image, cv2.COLOR_BGR2RGB)
    pil_im = Image.fromarray(cv2_im_rgb)
    draw = ImageDraw.Draw(pil_im)
    # Choose a font
    # font = ImageFont.load("arial.pil")
    font = ImageFont.truetype("img/FreeSerif.ttf", 20)
    # Draw the text
    # draw.text((0, 0), "cover", font=font)
    draw.text((100, 18), "cover", font=font, fill=(0,0,0))
    draw.text((356, 18), "stego", font=font, fill=(0,0,0))
    draw.text((600, 18), "secret", font=font, fill=(0,0,0))
    draw.text((800, 18), "secret reveald", font=font, fill=(0,0,0))
    # Save the image
    cv2_im_processed = cv2.cvtColor(np.array(pil_im), cv2.COLOR_RGB2BGR)
    cv2.imwrite(image_path.split('.')[0]+'_text.png', cv2_im_processed)


if __name__ == '__main__':
    # visulize_npy_result('logs/0403-0019')
    # visulize_npy_result('logs/0407-2119')

    # plot_validation_scores('logs/0510-2126-imagenet/log.txt')
    # plot_validation_scores('logs/0514-1037/log.txt')
    # plot_validation_scores('logs/0610-1843/log.txt')

    # plot_histogram('logs/histogram/voc/1/')
    # plot_residual('logs/histogram/voc/4/')

    # plot_histogram('logs/histogram/imagenet/2/')
    # plot_residual('logs/histogram/imagenet/2')
    # generate_model_result()

    # plot_histogram('/home/moliq/Documents/repos/TF_ISGAN/logs/histogram/lfw/1/')

    # generate_model_result_on_voc_lfw()
    # generate_model_result_on_imagenet()
    # generate_model_hist_result()

    #add_text()

    # generate_hist_in_dirctory('logs/0716-0024-voc-512-2/test_png/')
    # generate_hist_in_dirctory('logs/0714-1957-lfw-512/test_png/')
    # generate_hist_in_dirctory('logs/0714-1913/test_png/')
    # generate_hist_in_dirctory('logs/0718-1412/test_png/')
    # generate_hist_in_dirctory('logs/0718-1938/test_png/')
    # generate_hist_in_dirctory('logs/0718-1412/test_custom_png/')

    generate_hist_in_dirctory('logs/0722-1339-imagenet-ssim/test/')
    generate_hist_in_dirctory('logs/0722-2320-lfw-ssim/test/')

    # generate_residual_in_dirctory('logs/0716-0024-voc-512-2/test_png/')
    # generate_residual_in_dirctory('logs/0714-1957-lfw-512/test_png/')
    # generate_residual_in_dirctory('logs/0714-1913/test_png/')
    # generate_residual_in_dirctory('logs/0718-1412/test_png/')
    # generate_residual_in_dirctory('logs/0718-1938/test_png/')
    # generate_residual_in_dirctory('logs/0716-0024-voc-512-2/test_custom_png/')

    generate_residual_in_dirctory('logs/0722-1339-imagenet-ssim/test/')
    generate_residual_in_dirctory('logs/0722-2320-lfw-ssim/test/')