# -*- coding: utf-8
import os
os.environ["CUDA_VISIBLE_DEVICES"] = "0"

import math
import cv2
import numpy as np
from skimage import transform
import matplotlib.pyplot as plt
from SingleSizeModel import Model as EncodeModel
from train_decode import Model as DecodeModel
from SingleSizeModel import Model as DecodeModel_0


def sift_demo():
    psd_img_1 = cv2.imread('/home/gl/Documents/ophthalmology/data_sample/0001-微小内斜/0001_术前_中上.jpg', cv2.IMREAD_GRAYSCALE)
    psd_img_2 = cv2.imread('/home/gl/Documents/ophthalmology/data_sample/0001-微小内斜/0001_术前_中下.jpg', cv2.IMREAD_GRAYSCALE)

    sift = cv2.xfeatures2d.SIFT_create()

    psd_kp1, psd_des1 = sift.detectAndCompute(psd_img_1, None)
    psd_kp2, psd_des2 = sift.detectAndCompute(psd_img_2, None)

    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)

    flann = cv2.FlannBasedMatcher(index_params, search_params)
    matches = flann.knnMatch(psd_des1, psd_des2, k=2)
    goodMatch = []
    for m, n in matches:
        if m.distance < 0.50*n.distance:
            goodMatch.append(m)
    goodMatch = np.expand_dims(goodMatch, 1)
    print(goodMatch[:20])
    print(len(goodMatch))

    # img_out = cv2.drawMatchesKnn(psd_img_1, psd_kp1, psd_img_2, psd_kp2, matches, None, flags=2)
    img_out = cv2.drawMatchesKnn(psd_img_1, psd_kp1, psd_img_2, psd_kp2, goodMatch[:15], None, flags=2)

    cv2.imwrite('result.jpg', img_out)
    # cv2.imshow('image', img_out)


def surf_demo():
    import numpy as np
    import cv2
    from matplotlib import pyplot as plt

    imgname1 = 'E:/other/gakki101.jpg'
    imgname2 = 'E:/other/gakki102.jpg'

    surf = cv2.xfeatures2d.SURF_create()

    FLANN_INDEX_KDTREE = 0
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index_params, search_params)

    img1 = cv2.imread(imgname1)
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)  # 灰度处理图像
    kp1, des1 = surf.detectAndCompute(img1, None)  # des是描述子

    img2 = cv2.imread(imgname2)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    kp2, des2 = surf.detectAndCompute(img2, None)

    hmerge = np.hstack((gray1, gray2))  # 水平拼接
    cv2.imshow("gray", hmerge)  # 拼接显示为gray
    cv2.waitKey(0)

    img3 = cv2.drawKeypoints(img1, kp1, img1, color=(255, 0, 255))
    img4 = cv2.drawKeypoints(img2, kp2, img2, color=(255, 0, 255))

    hmerge = np.hstack((img3, img4))  # 水平拼接
    cv2.imshow("point", hmerge)  # 拼接显示为gray
    cv2.waitKey(0)

    matches = flann.knnMatch(des1, des2, k=2)

    good = []
    for m, n in matches:
        if m.distance < 0.7 * n.distance:
            good.append([m])
    img5 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good, None, flags=2)
    cv2.imshow("SURF", img5)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def orb_demo():
    import numpy as np
    import cv2
    from matplotlib import pyplot as plt

    imgname1 = 'E:/other/gakki101.jpg'
    imgname2 = 'E:/other/gakki102.jpg'

    orb = cv2.ORB_create()

    img1 = cv2.imread(imgname1)
    gray1 = cv2.cvtColor(img1, cv2.COLOR_BGR2GRAY)  # 灰度处理图像
    kp1, des1 = orb.detectAndCompute(img1, None)  # des是描述子

    img2 = cv2.imread(imgname2)
    gray2 = cv2.cvtColor(img2, cv2.COLOR_BGR2GRAY)
    kp2, des2 = orb.detectAndCompute(img2, None)

    hmerge = np.hstack((gray1, gray2))  # 水平拼接
    cv2.imshow("gray", hmerge)  # 拼接显示为gray
    cv2.waitKey(0)

    img3 = cv2.drawKeypoints(img1, kp1, img1, color=(255, 0, 255))
    img4 = cv2.drawKeypoints(img2, kp2, img2, color=(255, 0, 255))

    hmerge = np.hstack((img3, img4))  # 水平拼接
    cv2.imshow("point", hmerge)  # 拼接显示为gray
    cv2.waitKey(0)

    # BFMatcher解决匹配
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)
    # 调整ratio
    good = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good.append([m])

    img5 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good, None, flags=2)
    cv2.imshow("ORB", img5)
    cv2.waitKey(0)
    cv2.destroyAllWindows()


def run(imgname1):
    sift = cv2.xfeatures2d.SIFT_create()
    # FLANN 参数设计
    FLANN_INDEX_KDTREE = 1
    index_params = dict(algorithm=FLANN_INDEX_KDTREE, trees=5)
    search_params = dict(checks=50)
    flann = cv2.FlannBasedMatcher(index_params, search_params)

    img1 = cv2.imread(imgname1)
    kp1, des1 = sift.detectAndCompute(img1, None)  # des是描述子

    tform = transform.AffineTransform(scale=(1.2, 1.2), rotation=0.2, translation=(150, -200))
    img2 = transform.warp(img1, tform)
    img2 = (img2*255).astype(np.uint8)
    kp2, des2 = sift.detectAndCompute(img2, None)

    # hmerge = np.hstack((gray1, gray2))  # 水平拼接
    # cv2.imshow("gray", hmerge)  # 拼接显示为gray
    # cv2.waitKey(0)
    #
    # img3 = cv2.drawKeypoints(img1, kp1, img1, color=(255, 0, 255))
    # img4 = cv2.drawKeypoints(img2, kp2, img2, color=(255, 0, 255))

    # hmerge = np.hstack((img3, img4))  # 水平拼接
    # cv2.imshow("point", hmerge)  # 拼接显示为gray
    # cv2.waitKey(0)

    matches = flann.knnMatch(des1, des2, k=2)
    # matchesMask = [[0, 0] for i in range(len(matches))]

    good = []
    for m, n in matches:
        if m.distance < 0.4 * n.distance:
            good.append([m])
    print(len(good))
    img5 = cv2.drawMatchesKnn(img1, kp1, img2, kp2, good[:50], None, flags=2)
    cv2.imwrite('img/image_affin.jpg', img5)

def sift_kp(image):
    gray_image = cv2.cvtColor(image,cv2.COLOR_BGR2GRAY)
    sift = cv2.xfeatures2d_SIFT.create()
    kp,des = sift.detectAndCompute(image,None)
    kp_image = cv2.drawKeypoints(image,kp,None)
    return kp_image,kp,des

def find_max_response(kps):
    max_kp_response = 0
    max_kp_index = 0
    for idx, kp in enumerate(kps):
        if kp.response > max_kp_response:
            max_kp_response = kp.response
            max_kp_index = idx
    return max_kp_index

def sort_kps(kps):
    kps = sorted(kps, cmp=None, key=lambda x: x.response)
    return kps

def pt2xy(kp):
    kp_coord = kp.pt
    x_coord = int(round(kp_coord[0]))
    y_coord = int(round(kp_coord[1]))
    return (x_coord, y_coord)

def get_transformed_angle(kp2, kp1):
    if kp2.angle < kp1.angle:
        # rotation = int(round(kp1.angle - kp2.angle))
        rotation = kp1.angle - kp2.angle
    else:
        # rotation = int(round(360 - (kp2.angle - kp1.angle)))
        rotation = 360 - (kp2.angle - kp1.angle)
    return rotation

def get_transformed_angle_2(kp2, kp1, cols, rows):
    x1, y1 = kp1.pt[0] - cols/2., kp1.pt[1] - rows/2.
    x2, y2 = kp2.pt[0] - cols/2., kp2.pt[1] - rows/2.
    cos_theta = (x1*x2+y1*y2)/(x1*x1+y1*y1)
    rotation =  math.degrees(math.acos(cos_theta))
    # rotation = math.radians(360) - math.acos(cos_theta)
    return rotation

# def find_max_response(kps):
#     max_kp_response = 0
#     max_kp_index = 0
#     for idx, kp in enumerate(kps):
#         if kp.response > max_kp_response:
#             max_kp_response = kp.response
#             max_kp_index = idx
#     return max_kp_index

def get_good_match(des1,des2):
    bf = cv2.BFMatcher()
    matches = bf.knnMatch(des1, des2, k=2)
    good = []
    for m, n in matches:
        if m.distance < 0.75 * n.distance:
            good.append(m)
    return good

def siftImageAlignment(img1,img2):
   _,kp1,des1 = sift_kp(img1)
   _,kp2,des2 = sift_kp(img2)
   goodMatch = get_good_match(des1,des2)
   # match_image = cv2.drawMatchesKnn(img1, kp1, img2, kp2, goodMatch, None, flags=2)
   if len(goodMatch) > 4:
       ptsA= np.float32([kp1[m.queryIdx].pt for m in goodMatch]).reshape(-1, 1, 2)
       ptsB = np.float32([kp2[m.trainIdx].pt for m in goodMatch]).reshape(-1, 1, 2)
       ransacReprojThreshold = 4
       H, status =cv2.findHomography(ptsA,ptsB,cv2.RANSAC,ransacReprojThreshold)
       imgOut = cv2.warpPerspective(img2, H, (img1.shape[1],img1.shape[0]),flags=cv2.INTER_LINEAR + cv2.WARP_INVERSE_MAP)
   # return match_image, imgOut,H,status
   return imgOut,H,status

def image_align():
    imgname1 = 'img/4.JPEG'
    img1 = cv2.imread(imgname1)

    tform = transform.AffineTransform(scale=(1.2, 1.2), rotation=0.2, translation=(150, -200))
    img2 = transform.warp(img1, tform)
    img2 = (img2 * 255).astype(np.uint8)

    # match_image, imgOut, H, status = siftImageAlignment(img1,img2)
    imgOut, H, status = siftImageAlignment(img1,img2)

    cv2.imwrite('img/image_align.jpg', imgOut)
    # cv2.imwrite('img/image_affin.jpg', match_image)

def full_workflow():
    from SingleSizeModel import Model

    imgname1 = 'img/demo.jpg'
    water_mark_path = 'img/7.JPEG'

    raw_image = cv2.imread(imgname1)
    rows, cols, ch = raw_image.shape

    secret_image = cv2.imread(water_mark_path, 0)
    secret_image = cv2.resize(secret_image, (512, 512))
    secret_image = np.expand_dims(secret_image, 0)/255.
    # secret_image = np.stack([secret_image, secret_image, secret_image], axis=-1)/255.

    kp_image, kps, des = sift_kp(raw_image)


    hidden_kp_coord = kps[len(kps)//2].pt
    print(hidden_kp_coord)
    hidden_x_coord = int(round(hidden_kp_coord[0]))
    hidden_y_coord = int(round(hidden_kp_coord[1]))
    extract_image = raw_image[hidden_x_coord-256:hidden_x_coord+256, hidden_y_coord-256:hidden_y_coord+256, :] / 255.
    cv2.imwrite('/home/gl/tmp/cover.png', (extract_image*255).astype(np.uint8))
    #
    # extract_image = (extract_image *255).astype(np.uint8)
    # kp_image, kps, des = sift_kp(extract_image)
    # cv2.imwrite('img/kp.png', kp_image)
    #
    # tform = transform.AffineTransform(scale=(1.1, 1.1), rotation=math.radians(5), translation=(10, 10))
    # extract_image2 = cv2.warpPerspective(extract_image, tform.params, (extract_image.shape[1], extract_image.shape[0]))
    # kp_image, kps, des = sift_kp(extract_image2)
    # cv2.imwrite('img/kp2.png', kp_image)
    #
    # raw_image2 = cv2.warpPerspective(raw_image, tform.params, (cols, rows))
    # cv2.imwrite('img/cover_transform.png', raw_image2)

    # (2658.342041015625, 1387.6497802734375)
    # cv2.imwrite('img/extract_image.jpg', extract_image)

    hiddenmodel = Model()
    # stego = hiddenmodel.get_stego('logs/0718-1412-imagenet', np.expand_dims(extract_image, 0).astype(np.float32), secret_image.astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1113-2016', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    stego = hiddenmodel.get_stego('logs/1114-1908', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    cv2.imwrite('/home/gl/tmp/cover_hidden.png', stego[0])

    # hiddenmodel = Model()
    # # stego, secret_reveal = hiddenmodel.test_one_image('logs/1113-2016', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego, secret_reveal = hiddenmodel.test_one_image('logs/1114-1908', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))

    stego_noised = stego + np.random.normal(scale=5, size=stego.shape)
    cv2.imwrite('/home/gl/tmp/cover_hidden_add_gussian_noised.png', stego_noised[0])
    new_stego_image = raw_image.copy()
    new_stego_image[hidden_x_coord-256:hidden_x_coord+256, hidden_y_coord-256:hidden_y_coord+256, :] = stego_noised[0]

    tform = transform.AffineTransform(scale=(1.1, 1.1), rotation=math.radians(340), translation=(50, 50))
    # new_stego_image_affined = transform.warp(new_stego_image, tform)
    # new_stego_image_affined = (new_stego_image_affined * 255).astype(np.uint8)

    # pts1 = np.float32([[56, 65], [368, 52], [28, 387], [389, 390]])
    # pts2 = np.float32([[0, 0], [300, 0], [0, 300], [300, 300]])
    #
    # M = cv2.getPerspectiveTransform(pts1, pts2)
    # new_stego_image_affined = cv2.warpPerspective(new_stego_image, M, (rows, cols))
    new_stego_image_affined = cv2.warpPerspective(new_stego_image, tform.params, (cols, rows))
    cv2.imwrite('/home/gl/tmp/affined_cover.png', new_stego_image_affined)

    # pts1 = np.float32([[50, 50], [200, 50], [50, 200]])
    # pts2 = np.float32([[10, 100], [200, 50], [100, 250]])
    #
    # M = cv2.getAffineTransform(pts1, pts2)
    # new_stego_image_affined = cv2.warpAffine(new_stego_image, M, (cols, rows))

    imgOut, H, status = siftImageAlignment(raw_image, new_stego_image_affined)
    hidden_stego = imgOut[hidden_x_coord-256:hidden_x_coord+256, hidden_y_coord-256:hidden_y_coord+256, :]
    cv2.imwrite('/home/gl/tmp/cover_hidden_alligned.png', hidden_stego)

    diff = stego[0] - hidden_stego
    cv2.imwrite('/home/gl/tmp/alligned_difference.png', diff)

    revealmodel = Model()
    # final_secret = revealmodel.get_secret('logs/0718-1412-imagenet', np.expand_dims(hidden_stego, 0)/255.)
    final_secret = revealmodel.get_secret('logs/1113-2016', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1114-1908', np.expand_dims(hidden_stego, 0)/255.)

    plt.imshow((secret_image[0]*255).astype(np.uint8), cmap='gray')
    plt.imshow(final_secret[0,:,:,0], cmap='gray')
    plt.imshow(final_secret[0,:,:,0]>128, cmap='gray')

    cv2.imwrite('/home/gl/tmp/secret.png', (secret_image[0]*255).astype(np.uint8))
    cv2.imwrite('/home/gl/tmp/secret_revealed.png', (final_secret[0,:,:,0]>128).astype(np.uint8)*255)

    # diff2 = secret_image - final_secret

def draw_top10_kp(raw_image, top_i=-10, name='default'):

    _, kps, des = sift_kp(raw_image)
    sorted_kps_1 = sort_kps(kps)

    for i in range(top_i, 0):
        max_kp_i = sorted_kps_1[i]
        hidden_x_coord_i, hidden_y_coord_i = pt2xy(max_kp_i)

        kp_image_i = cv2.circle(raw_image.copy(), (hidden_x_coord_i, hidden_y_coord_i), 100, (0, 0, 255), 6)
        cv2.imwrite('/home/gl/tmp/%s_max_kp_%d.jpg'%(name, i), kp_image_i)


def testing():

    # imgname1 = 'img/demo.jpg'
    # imgname1 = 'img/IMGP7210.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7293.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7555.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7559.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7236.jpg'
    imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7306.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7188.jpg'
    water_mark_path = 'img/watermark_demo.JPEG'

    raw_image = cv2.imread(imgname1)
    rows, cols, ch = raw_image.shape

    secret_image = cv2.imread(water_mark_path, 0)
    secret_image = cv2.resize(secret_image, (512, 512))
    # secret_image[secret_image>0]= 255
    secret_image = np.expand_dims(secret_image, 0)/255.

    # cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))

    #########
    ######### Find max response keypoint

    _, kps, des = sift_kp(raw_image)
    sorted_kps_1 = sort_kps(kps)

    # draw_top10_kp(raw_image, 'cover')

    max_kp = sorted_kps_1[-1]
    # kp_image = cv2.drawKeypoints(raw_image, [max_kp], (0,0,255))
    hidden_x_coord, hidden_y_coord = pt2xy(max_kp)
    kp_image = cv2.circle(raw_image.copy(), (hidden_x_coord, hidden_y_coord), 100, (0, 0, 255), 6)
    cv2.imwrite('/home/gl/test/raw_image_with_kp.jpg', kp_image)
    cv2.imwrite('/home/gl/test/raw_image.jpg', raw_image)


    #########
    ######### Extract cover base on max response keypoint, get stego

    extract_image = raw_image[hidden_y_coord-256:hidden_y_coord+256, hidden_x_coord-256:hidden_x_coord+256, :] / 255.
    cv2.imwrite('/home/gl/test/cover.png', (extract_image*255).astype(np.uint8))

    hiddenmodel = EncodeModel()
    # stego = hiddenmodel.get_stego('logs/1113-2016-master-branch', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1214-1959', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1216-0133', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1217-2122', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1219-1454', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1219-1454/-50000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1219-1454/-25000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-12500', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-25000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-37500', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-50000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-100000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-112500', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    # stego = hiddenmodel.get_stego('logs/1223-1124/-150000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    stego = hiddenmodel.get_stego('logs/1223-1124/-225000', np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    cv2.imwrite('/home/gl/test/cover_hidden.png', stego[0])
    # deepmodel = Model()
    # stego, secret_reveal = hiddenmodel.test_one_image('logs/1110-1929', np.expand_dims(extract_image, 0).astype(np.float32), secret_image.astype(np.float32))

    stego_noised = stego
    stego_noised = np.clip(stego_noised + np.random.normal(scale=3, size=stego.shape), 0, 255).astype(np.uint8)
    cv2.imwrite('/home/gl/test/cover_hidden_add_gussian_noised.png', stego_noised[0])

    new_stego_image = raw_image.copy()
    new_stego_image[hidden_y_coord-256:hidden_y_coord+256, hidden_x_coord-256:hidden_x_coord+256, :] = stego_noised[0]

    # draw_top10_kp(new_stego_image, 'stego')

    #########
    ######### Affin transform on stego image

    new_stego_image_affined = new_stego_image


    # matrix = transform.AffineTransform(scale=(1, 1), rotation=math.radians(0), translation=(30, 0)).params[:2,:]
    # matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=10, scale=1)
    # matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=0, scale=1.1)
    # matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=0, scale=0.9)
    matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=5, scale=0.9)
    new_stego_image_affined = cv2.warpAffine(new_stego_image_affined, matrix, (cols, rows))

    # draw_top10_kp(new_stego_image_affined, '缩放0.9')
    # draw_top10_kp(new_stego_image_affined, '旋转5度')

    cv2.imwrite('/home/gl/test/raw_image_affined.jpg', new_stego_image_affined)

    #########
    ######### Find max response keypoint on stego image

    kp_image2, kps2, des2 = sift_kp(new_stego_image_affined)
    sorted_kps_2 = sort_kps(kps2)

    max_kp2 = sorted_kps_2[-1]
    hidden_x_coord2, hidden_y_coord2 = pt2xy(max_kp2)

    kp_image_2 = cv2.circle(new_stego_image_affined.copy(), (hidden_x_coord2, hidden_y_coord2), 100, (0, 0, 255), 6)
    cv2.imwrite('/home/gl/test/raw_image_with_kp_extracted.jpg', kp_image_2)


    # cover_transformed = new_stego_image_affined[hidden_y_coord2-256:hidden_y_coord2+256, hidden_x_coord2-256:hidden_x_coord2+256, :]
    # cv2.imwrite('/home/gl/tmp/cover_hidden_affined_extracted.png', cover_transformed)

    ##########
    ########## Alignment

    new_stego_image_aligned = new_stego_image_affined

    # # translate
    # translate = (hidden_x_coord - hidden_x_coord2, hidden_y_coord - hidden_y_coord2)
    # print 'translate difference ', translate
    # tform2 = transform.AffineTransform(scale=(1, 1), rotation=0, translation=translate)

    # ## rotate
    # # rotation = get_transformed_angle(max_kp2, max_kp)
    # rotation = get_transformed_angle_2(max_kp2, max_kp, cols, rows)
    # print 'angle differnce ', rotation
    # # tform2 = transform.AffineTransform(scale=(1, 1), rotation=radians, translation=(0,0))
    # matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=-1*rotation, scale=1)
    # new_stego_image_aligned = cv2.warpAffine(new_stego_image_aligned, matrix, (cols, rows))


    # #scale
    # scale = max_kp.size / max_kp2.size
    # print 'scale difference ', max_kp2.size / max_kp.size
    # matrix = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle=0, scale=scale)
    # new_stego_image_aligned = cv2.warpAffine(new_stego_image_aligned, matrix, (cols, rows))



    # cv2.imwrite('/home/gl/test/raw_cover_alligned.jpg', new_stego_image_aligned)
    hidden_stego = new_stego_image_aligned[hidden_y_coord2-256:hidden_y_coord2+256, hidden_x_coord2-256:hidden_x_coord2+256, :]
    # cv2.imwrite('/home/gl/test/cover_hidden_alligned.jpg', hidden_stego)
    # hidden_stego = cv2.imread('/home/gl/test/cover_hidden_alligned.jpg')
    cv2.imwrite('/home/gl/test/cover_hidden_alligned.png', hidden_stego)

    diff = stego[0] - hidden_stego
    cv2.imwrite('/home/gl/test/alligned_difference.png', diff)


    ##########
    ########## Recover secret image
    revealmodel = DecodeModel()
    # final_secret = revealmodel.get_secret('logs/0718-1412-imagenet', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1113-2016-master-branch', np.expand_dims(hidden_stego, 0) / 255.)
    # final_secret = revealmodel.get_secret('logs/1214-1959', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1216-0133', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1217-2122', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1218-1645', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1219-1454', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1219-1454/-50000', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1219-1454/-25000', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-12500', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-25000', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-37500', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-50000', np.expand_dims(hidden_stego, 0)/255.)
    final_secret = revealmodel.get_secret('logs/1223-1124/-100000', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-112500', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-150000', np.expand_dims(hidden_stego, 0)/255.)
    # final_secret = revealmodel.get_secret('logs/1223-1124/-225000', np.expand_dims(hidden_stego, 0)/255.)

    # plt.imshow(secret_image[0])
    # plt.imshow(final_secret[0], cmap='gray')
    cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))
    cv2.imwrite('/home/gl/test/secret_revealed.png', final_secret[0])
    cv2.imwrite('/home/gl/test/secret_revealed_threshold.png', (final_secret[0, :, :, 0] > 128).astype(np.uint8) * 255)
    print 'Done'
    # diff2 = secret_image - final_secret


def write_image_for_each_transform(images, out_dirs, name):
    for i, dir in enumerate(out_dirs):
        image_path = os.path.join(dir, name)
        cv2.imwrite(image_path, images[i])




def get_transform_images(image, cols, rows):
    matrix = transform.AffineTransform(scale=(1, 1), rotation=math.radians(0), translation=(5, 0)).params[:2,:]
    translate_image = cv2.warpAffine(image, matrix, (cols, rows))
    matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=10, scale=1)
    rotate_image = cv2.warpAffine(image, matrix, (cols, rows))
    matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=0, scale=1.1)
    scale_up_image = cv2.warpAffine(image, matrix, (cols, rows))
    matrix = cv2.getRotationMatrix2D((cols/2, rows/2), angle=0, scale=0.9)
    scale_down_image = cv2.warpAffine(image, matrix, (cols, rows))
    # matrix = cv2.getRotationMatrix2D((cols / 2, rows / 2), angle=5, scale=0.9)
    #scale_down_image = cv2.warpAffine(image, matrix, (cols, rows))
    gaussian_noised_image = np.clip(image + np.random.normal(scale=3, size=image.shape), 0, 255).astype(np.uint8)
    return [rotate_image, scale_up_image, scale_down_image, translate_image, gaussian_noised_image]



def test_all_in_one(ckpt):
    import tensorflow as tf

    if os.path.exists(ckpt + '.meta'):
        loader = ckpt
    else:
        loader = tf.train.latest_checkpoint(ckpt)

    model_names = os.path.basename(loader)

    transform_list = ['rotate10', 'scale1.1', 'scale0.9', 'translate5', 'gaussian5']
    out_dirs = [os.path.join('/home/gl/test/', model_names, i) for i in transform_list]
    for dir in out_dirs:
        if not os.path.exists(dir):
            os.makedirs(dir)


    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7293.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7555.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7559.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7236.jpg'
    imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7306.jpg'
    water_mark_path = 'img/watermark_demo.JPEG'

    raw_image = cv2.imread(imgname1)
    rows, cols, ch = raw_image.shape

    secret_image = cv2.imread(water_mark_path, 0)
    secret_image = cv2.resize(secret_image, (512, 512))
    # secret_image[secret_image>0]= 255
    secret_image = np.expand_dims(secret_image, 0)/255.
    # cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))

    #########
    ######### Find max response keypoint
    _, kps, des = sift_kp(raw_image)
    sorted_kps_1 = sort_kps(kps)
    # draw_top10_kp(raw_image, 'cover')
    max_kp = sorted_kps_1[-1]
    # kp_image = cv2.drawKeypoints(raw_image, [max_kp], (0,0,255))
    hidden_x_coord, hidden_y_coord = pt2xy(max_kp)
    kp_image = cv2.circle(raw_image.copy(), (hidden_x_coord, hidden_y_coord), 100, (0, 0, 255), 6)
    write_image_for_each_transform([kp_image]*5, out_dirs, name='raw_image_with_kp.jpg')
    write_image_for_each_transform([raw_image]*5, out_dirs, name='raw_image.jpg')

    #########
    ######### Extract cover base on max response keypoint, get stego
    extract_image = raw_image[hidden_y_coord-256:hidden_y_coord+256, hidden_x_coord-256:hidden_x_coord+256, :] / 255.
    write_image_for_each_transform([(extract_image*255).astype(np.uint8)]*5, out_dirs, name='cover.png')

    hiddenmodel = EncodeModel()
    stego = hiddenmodel.get_stego(loader, np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    write_image_for_each_transform([stego[0]]*5, out_dirs, name='cover_hidden.png')


    #########
    ######### stego transforms
    new_stego_image = raw_image.copy()
    new_stego_image[hidden_y_coord - 256:hidden_y_coord + 256, hidden_x_coord - 256:hidden_x_coord + 256, :] = stego[0]

    new_stego_transformed_images = get_transform_images(new_stego_image, cols, rows)

    write_image_for_each_transform(new_stego_transformed_images, out_dirs, name='raw_image_affined.jpg')


    #########
    ######### Find max response keypoint on stego image

    kp_images = []
    new_stego_image_extract = []
    for new_stego_image_affined in new_stego_transformed_images:
        kp_image_i, kps_i, des_i = sift_kp(new_stego_image_affined)
        sorted_kps_i = sort_kps(kps_i)
        max_kp_i = sorted_kps_i[-1]
        hidden_x_coord_i, hidden_y_coord_i = pt2xy(max_kp_i)
        kp_image_i = cv2.circle(new_stego_image_affined.copy(), (hidden_x_coord_i, hidden_y_coord_i), 100, (0, 0, 255), 6)
        extracted_stego_i = new_stego_image_affined[hidden_y_coord_i - 256:hidden_y_coord_i + 256, hidden_x_coord_i - 256:hidden_x_coord_i + 256, :]
        kp_images.append(kp_image_i)
        new_stego_image_extract.append(extracted_stego_i)

    write_image_for_each_transform(kp_images, out_dirs, name='raw_image_with_affined_kp.jpg')
    write_image_for_each_transform(new_stego_image_extract, out_dirs, name='cover_hidden_extracted.png')


    ##########
    ########## Recover secret image
    new_stego_image_extract = np.stack(new_stego_image_extract, 0)
    revealmodel = DecodeModel()
    final_secrets = revealmodel.get_secret(loader, new_stego_image_extract/255.)
    write_image_for_each_transform([(secret_image[0] * 255).astype(np.uint8)]*5, out_dirs, name='secret.png')
    write_image_for_each_transform([final_secrets[i,:,:,0] for i in range(5)], out_dirs, name='secret_revealed.png')
    write_image_for_each_transform([(final_secrets[i,:,:,0]>128).astype(np.uint8) * 255 for i in range(5)], out_dirs, name='secret_revealed_threshold_of_128.png')


    # cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))
    # cv2.imwrite('/home/gl/test/secret_revealed.png', final_secret[0])
    # cv2.imwrite('/home/gl/test/secret_revealed_threshold.png', (final_secret[0, :, :, 0] > 128).astype(np.uint8) * 255)
    print 'Done'


def test_all_in_one_2(ckpt):
    import tensorflow as tf

    if os.path.exists(ckpt + '.meta'):
        loader = ckpt
    else:
        loader = tf.train.latest_checkpoint(ckpt)

    model_names = os.path.basename(loader)

    transform_list = ['rotate10', 'scale1.1', 'scale0.9', 'translate5', 'gaussian5']
    out_dirs = [os.path.join('/home/gl/test/', os.path.basename(ckpt), model_names, i) for i in transform_list]
    for dir in out_dirs:
        if not os.path.exists(dir):
            os.makedirs(dir)


    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7293.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7555.jpg'
    imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7559.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7236.jpg'
    # imgname1 = '/home/gl/Downloads/20181031扬州/IMGP7306.jpg'
    water_mark_path = 'img/watermark_demo.JPEG'

    raw_image = cv2.imread(imgname1)
    rows, cols, ch = raw_image.shape

    secret_image = cv2.imread(water_mark_path, 0)
    secret_image = cv2.resize(secret_image, (512, 512))
    secret_image[secret_image>=128]= 255
    secret_image[secret_image<128]= 0
    secret_image = np.expand_dims(secret_image, 0)/255.
    # cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))

    #########
    ######### Find max response keypoint
    _, kps, des = sift_kp(raw_image)
    sorted_kps_1 = sort_kps(kps)
    # draw_top10_kp(raw_image, 'cover')
    max_kp = sorted_kps_1[-1]
    # kp_image = cv2.drawKeypoints(raw_image, [max_kp], (0,0,255))
    hidden_x_coord, hidden_y_coord = pt2xy(max_kp)
    kp_image = cv2.circle(raw_image.copy(), (hidden_x_coord, hidden_y_coord), 100, (0, 0, 255), 6)
    write_image_for_each_transform([kp_image]*5, out_dirs, name='raw_image_with_kp.jpg')
    write_image_for_each_transform([raw_image]*5, out_dirs, name='raw_image.jpg')

    #########
    ######### Extract cover base on max response keypoint, get stego
    extract_image = raw_image[hidden_y_coord-256:hidden_y_coord+256, hidden_x_coord-256:hidden_x_coord+256, :] / 255.
    write_image_for_each_transform([(extract_image*255).astype(np.uint8)]*5, out_dirs, name='cover.png')

    hiddenmodel = EncodeModel()
    stego = hiddenmodel.get_stego(loader, np.expand_dims(extract_image, 0).astype(np.float32), np.expand_dims(secret_image, -1).astype(np.float32))
    write_image_for_each_transform([stego[0]]*5, out_dirs, name='cover_hidden.png')


    #########
    ######### stego transforms
    new_stego_image = raw_image.copy()
    new_stego_image[hidden_y_coord - 256:hidden_y_coord + 256, hidden_x_coord - 256:hidden_x_coord + 256, :] = stego[0]

    new_stego_transformed_images = get_transform_images(new_stego_image, cols, rows)

    write_image_for_each_transform(new_stego_transformed_images, out_dirs, name='raw_image_affined.jpg')


    #########
    ######### Find max response keypoint on stego image

    kp_images = []
    new_stego_image_extract = []
    for new_stego_image_affined in new_stego_transformed_images:
        kp_image_i, kps_i, des_i = sift_kp(new_stego_image_affined)
        sorted_kps_i = sort_kps(kps_i)
        max_kp_i = sorted_kps_i[-1]
        hidden_x_coord_i, hidden_y_coord_i = pt2xy(max_kp_i)
        kp_image_i = cv2.circle(new_stego_image_affined.copy(), (hidden_x_coord_i, hidden_y_coord_i), 100, (0, 0, 255), 6)
        extracted_stego_i = new_stego_image_affined[hidden_y_coord_i - 256:hidden_y_coord_i + 256, hidden_x_coord_i - 256:hidden_x_coord_i + 256, :]
        kp_images.append(kp_image_i)
        new_stego_image_extract.append(extracted_stego_i)

    write_image_for_each_transform(kp_images, out_dirs, name='raw_image_with_affined_kp.jpg')
    write_image_for_each_transform(new_stego_image_extract, out_dirs, name='cover_hidden_extracted.png')


    ##########
    ########## Recover secret image
    new_stego_image_extract = np.stack(new_stego_image_extract, 0)
    revealmodel = DecodeModel_0()
    final_secrets = revealmodel.get_secret(loader, new_stego_image_extract/255.)
    write_image_for_each_transform([(secret_image[0] * 255).astype(np.uint8)]*5, out_dirs, name='secret.png')
    write_image_for_each_transform([final_secrets[i,:,:,0] for i in range(5)], out_dirs, name='secret_revealed.png')
    write_image_for_each_transform([(final_secrets[i,:,:,0]>128).astype(np.uint8) * 255 for i in range(5)], out_dirs, name='secret_revealed_threshold_of_128.png')


    # cv2.imwrite('/home/gl/test/secret.png', (secret_image[0] * 255).astype(np.uint8))
    # cv2.imwrite('/home/gl/test/secret_revealed.png', final_secret[0])
    # cv2.imwrite('/home/gl/test/secret_revealed_threshold.png', (final_secret[0, :, :, 0] > 128).astype(np.uint8) * 255)
    print 'Done'




if __name__ == '__main__':
    # sift_demo()
    # surf_demo()
    # run('/mnt/2T/moliq/Documents/repos/TF_ISGAN/img/demo.jpg')
    # run('img/4.JPEG')
    # image_align()
    # full_workflow()
    # testing()
    # test_all_in_one('logs/1223-1124/-100000')
    # test_all_in_one('logs/1223-1124/-225000')
    # test_all_in_one_2('logs/1230-0107')
    test_all_in_one_2('logs/1225-2029')
    # test_all_in_one_2('logs/1226-1701')
    # test_all_in_one_2('logs/1227-1526')